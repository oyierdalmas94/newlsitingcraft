import { useEffect, useState } from 'react';
import { api } from '@appdeploy/client';
import { Activity, Bell, Check, Clock3, ExternalLink, Globe2, Pause, Play, Plus, RefreshCw, ShieldCheck } from 'lucide-react';

type Monitor = {
  id: string;
  businessName: string;
  website: string;
  location: string;
  contactEmail?: string;
  cadence: 'daily' | 'weekly';
  status: 'Active' | 'Paused';
  nextRunAt: string;
  lastRunAt?: string;
  lastStatus?: string;
  lastScore?: number;
  lastFindingsCount?: number;
  lastAuditId?: string;
  lastError?: string;
};

type Run = {
  id: string;
  businessName: string;
  website: string;
  trigger: string;
  status: string;
  auditId?: string;
  score?: number;
  findingsCount?: number;
  error?: string;
  completedAt: string;
};

export default function AutomationCentre() {
  const [monitors, setMonitors] = useState<Monitor[]>([]);
  const [runs, setRuns] = useState<Run[]>([]);
  const [apifyReady, setApifyReady] = useState(false);
  const [businessDiscoveryReady, setBusinessDiscoveryReady] = useState(false);
  const [businessName, setBusinessName] = useState('');
  const [website, setWebsite] = useState('');
  const [location, setLocation] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [cadence, setCadence] = useState<'daily' | 'weekly'>('weekly');
  const [permissionConfirmed, setPermissionConfirmed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [notice, setNotice] = useState('');

  const load = async () => {
    const [automationResponse, runResponse, integrationResponse] = await Promise.all([
      api.get('/api/automations'),
      api.get('/api/automations/runs'),
      api.get('/api/integrations/status'),
    ]);
    setMonitors(automationResponse.data.automations || []);
    setRuns(runResponse.data.runs || []);
    setApifyReady(Boolean(integrationResponse.data.apifyConfigured));
    setBusinessDiscoveryReady(Boolean(integrationResponse.data.businessDiscovery?.enabled));
  };

  useEffect(() => {
    load().catch(err => setErrorMessage(err instanceof Error ? err.message : 'Could not load automation settings.'));
  }, []);

  const createMonitor = async (event: React.FormEvent) => {
    event.preventDefault();
    setLoading(true);
    setErrorMessage('');
    setNotice('');
    try {
      const response = await api.post('/api/automations', {
        businessName,
        website,
        location,
        contactEmail,
        cadence,
        permissionConfirmed,
      });
      setNotice(response.data.note || 'Website monitor scheduled.');
      setBusinessName('');
      setWebsite('');
      setLocation('');
      setContactEmail('');
      setPermissionConfirmed(false);
      await load();
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Could not create the monitor.');
    } finally {
      setLoading(false);
    }
  };

  const runNow = async (monitor: Monitor) => {
    setBusyId(monitor.id);
    setErrorMessage('');
    setNotice('');
    try {
      const response = await api.post('/api/automations/' + monitor.id + '/run', {});
      setNotice('Audit completed for ' + monitor.businessName + '. Score: ' + response.data.audit.score + '/100. ' + response.data.note);
      await load();
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'The monitor could not run. Check its run history.');
      await load().catch(() => undefined);
    } finally {
      setBusyId('');
    }
  };

  const toggle = async (monitor: Monitor) => {
    setBusyId(monitor.id);
    setErrorMessage('');
    try {
      await api.post('/api/automations/' + monitor.id + (monitor.status === 'Active' ? '/pause' : '/resume'), {});
      setNotice(monitor.status === 'Active' ? 'Scheduled monitoring paused.' : 'Scheduled monitoring resumed.');
      await load();
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Could not update the monitor.');
    } finally {
      setBusyId('');
    }
  };

  const formatDate = (value?: string) => value ? new Date(value).toLocaleString() : 'Not yet run';

  return (
    <>
      <div className="page-intro">
        <div className="eyebrow">LISTINGCRAFT WORKFLOW ENGINE</div>
        <h1>Automation centre</h1>
        <p>Schedule real website crawls and evidence-based audits. Review every run, pause a workflow at any time, and keep all outreach under human approval.</p>
      </div>

      {(errorMessage || notice) && <div className={errorMessage ? 'error-box' : 'notice-box'}>{errorMessage || notice}<button onClick={() => { setErrorMessage(''); setNotice(''); }}>×</button></div>}

      <div className="automation-status-grid">
        <div className="panel">
          <div className="automation-head"><Activity size={20}/><span className={'priority-tag ' + (apifyReady ? 'low' : 'high')}>{apifyReady ? 'Connected' : 'Setup required'}</span></div>
          <h3>Apify website crawler</h3>
          <p>{apifyReady ? 'The API token is present. Actual actor runs are still subject to website accessibility, robots.txt and provider execution.' : 'Add APIFY_API_TOKEN through AppDeploy secure settings before creating scheduled monitors.'}</p>
          <small>Maximum 3 pages per monitor run · Monthly audit allowance applies.</small>
        </div>
        <div className="panel">
          <div className="automation-head"><Globe2 size={20}/><span className={'priority-tag ' + (businessDiscoveryReady ? 'low' : 'high')}>{businessDiscoveryReady ? 'Enabled' : 'Source review required'}</span></div>
          <h3>Automatic business discovery</h3>
          <p>{businessDiscoveryReady ? 'Business discovery provider is enabled.' : 'Google Places discovery remains blocked until commercial-use and source-terms clearance is documented. No business leads are fabricated or silently imported.'}</p>
          <small>Agreed discovery cap: 50 businesses per run.</small>
        </div>
        <div className="panel">
          <div className="automation-head"><Bell size={20}/><span className="priority-tag low">Approval required</span></div>
          <h3>Proposal and outreach controls</h3>
          <p>Website audits are saved to Audit history. Generate a proposal from the actual findings, review it, and approve each email yourself.</p>
          <small>No automatic emails or calls are placed.</small>
        </div>
      </div>

      <div className="automation-layout">
        <form className="scan-card automation-form" onSubmit={createMonitor}>
          <div className="scan-card-title">
            <div className="scan-symbol"><Plus size={20}/></div>
            <div><h2>Schedule a website monitor</h2><p>Start with a business you have permission to review.</p></div>
          </div>
          <label>Business name *</label>
          <input required value={businessName} onChange={event => setBusinessName(event.target.value)} placeholder="e.g. Your pilot business"/>
          <label>Public website URL *</label>
          <input required type="url" value={website} onChange={event => setWebsite(event.target.value)} placeholder="https://example.com"/>
          <label>City / country *</label>
          <input required value={location} onChange={event => setLocation(event.target.value)} placeholder="e.g. Nairobi, Kenya"/>
          <label>Business contact email <span>OPTIONAL</span></label>
          <input type="email" value={contactEmail} onChange={event => setContactEmail(event.target.value)} placeholder="owner@example.com"/>
          <label>Monitoring frequency</label>
          <select value={cadence} onChange={event => setCadence(event.target.value as 'daily' | 'weekly')}>
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
          </select>
          <label className="permission-check automation-permission">
            <input type="checkbox" checked={permissionConfirmed} onChange={event => setPermissionConfirmed(event.target.checked)}/>
            I confirm I own this website or have permission to crawl it, and its published policies permit this monitoring.
          </label>
          <button className="primary-button scan-submit" type="submit" disabled={loading || !apifyReady || !permissionConfirmed}>
            {loading ? 'Saving monitor…' : 'Create scheduled monitor'}
          </button>
          {!apifyReady && <p className="email-setup-warning">Apify must be configured before a monitor can be created.</p>}
          <p className="privacy-line"><ShieldCheck size={14}/> The first scheduled run is in 24 hours or 7 days. Use Run now to test immediately. Each completed audit uses your monthly scan allowance.</p>
        </form>

        <div className="scan-aside">
          <div className="aside-title">WHAT THE AUTOMATION DOES</div>
          <div className="check-item"><div className="check-icon"><Globe2 size={17}/></div><div><b>1. Crawl permitted pages</b><p>Apify retrieves up to three pages and respects robots.txt.</p></div></div>
          <div className="check-item"><div className="check-icon"><Activity size={17}/></div><div><b>2. Analyze real page evidence</b><p>AI scores only the retrieved website content and records its findings.</p></div></div>
          <div className="check-item"><div className="check-icon"><Check size={17}/></div><div><b>3. Save a real audit</b><p>The report appears in Audit history and can be used in Proposal studio.</p></div></div>
          <div className="check-item"><div className="check-icon"><Clock3 size={17}/></div><div><b>4. Repeat on schedule</b><p>Daily or weekly checks run in the background. Pause or resume any monitor.</p></div></div>
          <div className="aside-disclaimer">Property listing monitoring needs an authorized MLS, RESO or partner feed. Automatic prospect email and voice outreach are not enabled; each email still needs your review and approval.</div>
        </div>
      </div>

      <div className="section-heading"><div><h3>Scheduled monitors</h3><p>{monitors.filter(item => item.status === 'Active').length} active · {monitors.length} total</p></div><button className="outline-button" type="button" onClick={() => load().catch(() => setErrorMessage('Refresh failed.'))}><RefreshCw size={14}/> Refresh</button></div>
      <div className="automation-monitor-list">
        {monitors.map(monitor => (
          <div className="opportunity-card automation-monitor" key={monitor.id}>
            <div className="automation-monitor-main">
              <b>{monitor.businessName}</b>
              <span>{monitor.website} · {monitor.location}</span>
              <small>{monitor.cadence} · Next run: {formatDate(monitor.nextRunAt)}</small>
              <small>Last run: {formatDate(monitor.lastRunAt)} · {monitor.lastStatus || 'Not run yet'}</small>
              {monitor.lastError && <small className="automation-error">{monitor.lastError}</small>}
            </div>
            <span className={'priority-tag ' + (monitor.status === 'Active' ? 'low' : 'high')}>{monitor.status}</span>
            <div className="automation-actions">
              <button className="outline-button" type="button" disabled={busyId === monitor.id} onClick={() => runNow(monitor)}><Play size={13}/>{busyId === monitor.id ? 'Running…' : 'Run now'}</button>
              <button className="outline-button" type="button" disabled={busyId === monitor.id} onClick={() => toggle(monitor)}>{monitor.status === 'Active' ? <Pause size={13}/> : <Play size={13}/>} {monitor.status === 'Active' ? 'Pause' : 'Resume'}</button>
            </div>
          </div>
        ))}
        {!monitors.length && <div className="empty-state">No scheduled monitors yet. Add a permitted pilot website to create your first real automation.</div>}
      </div>

      <div className="section-heading"><div><h3>Automation run history</h3><p>Real results only. Failed crawls are recorded as failures, never as successful audits.</p></div></div>
      <div className="automation-run-list">
        {runs.map(run => (
          <div className="automation-run" key={run.id}>
            <span className={'priority-tag ' + (run.status === 'Completed' ? 'low' : 'high')}>{run.status}</span>
            <div><b>{run.businessName}</b><small>{run.trigger} · {formatDate(run.completedAt)}</small></div>
            {run.status === 'Completed' ? <small>Score {run.score}/100 · {run.findingsCount} findings · Audit {run.auditId}</small> : <small className="automation-error">{run.error}</small>}
          </div>
        ))}
        {!runs.length && <div className="empty-state">No automation runs yet.</div>}
      </div>
    </>
  );
}
