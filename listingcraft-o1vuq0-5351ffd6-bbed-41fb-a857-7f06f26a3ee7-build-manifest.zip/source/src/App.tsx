import { useEffect, useMemo, useState } from 'react';
import { api, auth } from '@appdeploy/client';
import AutomationCentre from './components/AutomationCentre';
import {
  Activity, ArrowUpRight, BadgeCheck, BarChart3, Bell, Building2, Check,
  ChevronDown, Clock3, Download, ExternalLink, FileSearch, FileText, Globe2,
  LayoutDashboard, LifeBuoy, ListChecks, LogOut, Menu, Plus, Search,
  Settings, ShieldCheck, Sparkles, Target, TrendingUp, Users, X, Zap,
} from 'lucide-react';

type Finding = { title: string; severity: 'High' | 'Medium' | 'Low'; category: string; evidence: string; recommendation: string };
type Audit = { id: string; businessName: string; website: string; location: string; score: number; summary: string; findings: Finding[]; strengths: string[]; scannedAt: string; sourceTitle?: string };
type Proposal = { id: string; sourceAuditId: string; businessName: string; website: string; recipientEmail: string; subject: string; emailBody: string; executiveSummary: string; proposedSolution: string; status: string; createdAt: string; acceptedAt?: string; providerMessageId?: string };
type Prospect = { id: string; businessName: string; website: string; contactEmail: string; notes: string; status: string; createdAt: string };
type Opportunity = { id: string; kind: 'business' | 'property'; title: string; location: string; industry: string; sourceUrl: string; details: string; status: string; createdAt: string };
type Plan = { plan: string; planName: string; subscriptionStatus: string; hasCustomer: boolean; usage: { count: number; limit: number; month: string } };
type User = { userId: string; email?: string; name?: string };
const planCards = [
  { id: 'starter', name: 'Starter', usd: '$29', kes: 'KSh 3,900', scans: '15 audits / month', features: ['AI website audits', 'Persistent audit history', 'Exportable reports'] },
  { id: 'growth', name: 'Growth', usd: '$79', kes: 'KSh 10,600', scans: '100 audits / month', features: ['Everything in Starter', 'Agency prospect CRM', 'Client-ready reports', 'Priority workflow'], popular: true },
  { id: 'agency', name: 'Agency', usd: '$199', kes: 'KSh 26,900', scans: '500 audits / month', features: ['Everything in Growth', 'High-volume prospecting', 'Advanced account controls', 'White-label workflow (roadmap)'] },
];
function scoreLabel(score: number) { return score >= 80 ? 'Strong' : score >= 60 ? 'Needs attention' : 'At risk'; }
function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [signingIn, setSigningIn] = useState(false);
  const [active, setActive] = useState('Overview');
  const [url, setUrl] = useState('');
  const [business, setBusiness] = useState('');
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [notice, setNotice] = useState('');
  const [audit, setAudit] = useState<Audit | null>(null);
  const [history, setHistory] = useState<Audit[]>([]);
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [proposalAuditId, setProposalAuditId] = useState('');
  const [proposalEmail, setProposalEmail] = useState('');
  const [proposalOffer, setProposalOffer] = useState('');
  const [proposalDraft, setProposalDraft] = useState<Proposal | null>(null);
  const [proposalLoading, setProposalLoading] = useState(false);
  const [emailSetup, setEmailSetup] = useState<{ configured: boolean; missing: string[]; fromEmail?: string; fromName?: string; dailyLimit?: number }>({ configured: false, missing: [] });
  const [emailSetupLoading, setEmailSetupLoading] = useState(false);
  const [sendingProposal, setSendingProposal] = useState(false);
  const [sendConfirmed, setSendConfirmed] = useState(false);
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [oppKind, setOppKind] = useState<'business' | 'property'>('business');
  const [oppTitle, setOppTitle] = useState('');
  const [oppLocation, setOppLocation] = useState('');
  const [oppIndustry, setOppIndustry] = useState('');
  const [oppUrl, setOppUrl] = useState('');
  const [oppDetails, setOppDetails] = useState('');
  const [discoveryTerm, setDiscoveryTerm] = useState('');
  const [discoveryCountryCode, setDiscoveryCountryCode] = useState('ke');
  const [searchPermission, setSearchPermission] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);
  const [contactUrlList, setContactUrlList] = useState('');
  const [contactPermission, setContactPermission] = useState(false);
  const [contactLoading, setContactLoading] = useState(false);
  const [contactResults, setContactResults] = useState<Array<{ businessName: string; website: string; contactEmail: string; notes: string; status: string }>>([]);

  const [crawlUrl, setCrawlUrl] = useState('');
  const [crawlPermission, setCrawlPermission] = useState(false);
  const [crawlResults, setCrawlResults] = useState<Array<{ url: string; title: string; text: string }>>([]);
  const [crawlLoading, setCrawlLoading] = useState(false);
  const [plan, setPlan] = useState<Plan | null>(null);
  const currency = 'kes';
  const [filter, setFilter] = useState('All');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [prospectName, setProspectName] = useState('');
  const [prospectWebsite, setProspectWebsite] = useState('');
  const [prospectEmail, setProspectEmail] = useState('');
  const [prospectNotes, setProspectNotes] = useState('');
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [installHelp, setInstallHelp] = useState(false);

  const loadWorkspace = async () => {
    const [me, audits, prospectsResponse, billing, opportunitiesResponse, proposalsResponse] = await Promise.all([
      api.get('/api/me'),
      api.get('/api/audits'),
      api.get('/api/prospects'),
      api.get('/api/billing/status'),
      api.get('/api/opportunities'),
      api.get('/api/proposals'),
    ]);
    setUser(me.data.user);
    setHistory(audits.data.audits || []);
    setProposalAuditId(current => current || audits.data.audits?.[0]?.id || '');
    setProposals(proposalsResponse.data.proposals || []);
    setProspects(prospectsResponse.data.prospects || []);
    setOpportunities(opportunitiesResponse.data.opportunities || []);
    setPlan(billing.data);
  };

  useEffect(() => {
    const onInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event);
    };
    window.addEventListener('beforeinstallprompt', onInstall);
    return () => window.removeEventListener('beforeinstallprompt', onInstall);
  }, []);

  useEffect(() => {
    let active = true;
    auth.getUser().then(async current => {
      if (!active) return;
      setUser(current);
      if (current) {
        try {
          await loadWorkspace();
          const params = new URLSearchParams(window.location.search);
          const reference = params.get('reference');
          if (params.get('billing') === 'success' && reference) {
            await api.post('/api/billing/confirm', { reference });
            await loadWorkspace();
            setNotice('Your subscription is active. Welcome to ListingCraft!');
            window.history.replaceState({}, '', window.location.pathname);
          } else if (params.get('billing') === 'cancelled') {
            setNotice('Checkout was cancelled. No subscription was started.');
            window.history.replaceState({}, '', window.location.pathname);
          }
        } catch (err) {
          setErrorMsg(err instanceof Error ? err.message : 'Could not load your workspace.');
        }
      }
      setAuthLoading(false);
    }).catch(() => {
      if (active) {
        setAuthLoading(false);
        setErrorMsg('Sign-in could not be restored. Please try signing in again.');
      }
    });
    return () => { active = false; };
  }, []);

  const signIn = async () => {
    setSigningIn(true);
    setErrorMsg('');
    try { await auth.signInWithRedirect(); }
    catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Sign-in could not start. Please retry.');
      setSigningIn(false);
    }
  };

  const signOut = async () => {
    await auth.signOut();
    setUser(null); setHistory([]); setProposals([]); setProposalDraft(null); setProspects([]); setPlan(null); setAudit(null); setActive('Overview');
  };

  const change = (name: string) => { setActive(name); setMobileOpen(false); setErrorMsg(''); };
  const saveAudit = (item: Audit) => { setAudit(item); setActive('Audit report'); };
  const runScan = async () => {
    if (!url.trim()) { setErrorMsg('Enter a public website URL to start an audit.'); return; }
    let normalized = url.trim();
    if (!/^https?:\/\//i.test(normalized)) normalized = 'https://' + normalized;
    try {
      const parsed = new URL(normalized);
      if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Only public HTTP or HTTPS websites can be scanned.');
    } catch { setErrorMsg('Enter a valid website address, such as https://example.com.'); return; }
    setLoading(true); setErrorMsg(''); setNotice('');
    try {
      const response = await api.post('/api/audit', { url: normalized, businessName: business.trim(), location: location.trim() });
      const item = response.data.audit as Audit;
      setAudit(item);
      const audits = await api.get('/api/audits');
      setHistory(audits.data.audits || []);
      const billing = await api.get('/api/billing/status');
      setPlan(billing.data);
      setActive('Audit report');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'The audit could not be completed. Please retry.');
    } finally { setLoading(false); }
  };

  const addProspect = async () => {
    if (!prospectName.trim()) { setErrorMsg('Enter a business name for this prospect.'); return; }
    setLoading(true); setErrorMsg('');
    try {
      const response = await api.post('/api/prospects', { businessName: prospectName, website: prospectWebsite, contactEmail: prospectEmail, notes: prospectNotes });
      setProspects(prev => [response.data.prospect, ...prev]);
      setProspectName(''); setProspectWebsite(''); setProspectEmail(''); setProspectNotes('');
      setNotice('Prospect saved to your private workspace.');
    } catch (err) { setErrorMsg(err instanceof Error ? err.message : 'Could not save this prospect.'); }
    finally { setLoading(false); }
  };

  const saveOpportunity = async (kind: 'business' | 'property' = oppKind) => {
    if (!oppTitle.trim() || !oppLocation.trim()) { setErrorMsg('Add a name and location before saving this opportunity.'); return; }
    if (oppUrl.trim()) { try { const parsed = new URL(oppUrl.trim()); if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('invalid'); } catch { setErrorMsg('Source URL must be a valid public HTTP or HTTPS address.'); return; } }
    setLoading(true); setErrorMsg('');
    try {
      const response = await api.post('/api/opportunities', { kind, title: oppTitle, location: oppLocation, industry: oppIndustry, sourceUrl: oppUrl, details: oppDetails });
      setOpportunities(prev => [response.data.opportunity, ...prev]);
      setOppTitle(''); setOppLocation(''); setOppIndustry(''); setOppUrl(''); setOppDetails('');
      setNotice(kind === 'property' ? 'Property opportunity saved to your workspace.' : 'Business opportunity saved to your workspace.');
    } catch (err) { setErrorMsg(err instanceof Error ? err.message : 'Could not save this opportunity.'); }
    finally { setLoading(false); }
  };


  const generateProposal = async () => {
    const selectedAudit = history.find(item => item.id === proposalAuditId) || history[0];
    if (!selectedAudit) {
      setErrorMsg('Run and save a website audit before generating a proposal.');
      return;
    }
    if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(proposalEmail.trim())) {
      setErrorMsg('Enter a valid recipient email address.');
      return;
    }
    setProposalLoading(true);
    setErrorMsg('');
    setNotice('');
    try {
      const response = await api.post('/api/proposals/generate', {
        auditId: selectedAudit.id,
        recipientEmail: proposalEmail.trim(),
        offerDescription: proposalOffer.trim(),
      });
      const saved = response.data.proposal as Proposal;
      setProposalDraft(saved);
      setProposals(previous => [saved, ...previous.filter(item => item.id !== saved.id)]);
      setNotice('Proposal draft generated from saved audit evidence and stored in your private workspace.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'The proposal could not be generated. No draft was saved.');
    } finally {
      setProposalLoading(false);
    }
  };

  const checkEmailSetup = async () => {
    setEmailSetupLoading(true);
    try {
      const response = await api.get('/api/email/status');
      setEmailSetup(response.data);
    } catch (err) {
      setEmailSetup({ configured: false, missing: ['Email configuration could not be checked'] });
      setErrorMsg(err instanceof Error ? err.message : 'Could not check the email configuration.');
    } finally {
      setEmailSetupLoading(false);
    }
  };

  const sendProposal = async () => {
    if (!proposalDraft) return;
    if (!sendConfirmed) {
      setErrorMsg('Confirm that this is relevant business outreach and the recipient has not opted out.');
      return;
    }
    setSendingProposal(true);
    setErrorMsg('');
    setNotice('');
    try {
      const response = await api.post('/api/proposals/send', {
        proposalId: proposalDraft.id,
        confirmRecipientPermission: true,
      });
      const updated = { ...proposalDraft, status: 'Accepted', acceptedAt: response.data.acceptedAt, providerMessageId: response.data.providerMessageId };
      setProposalDraft(updated);
      setProposals(previous => previous.map(item => item.id === updated.id ? updated : item));
      setSendConfirmed(false);
      setNotice('SendGrid accepted the email request. This does not confirm inbox delivery.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'SendGrid did not confirm acceptance. Check the draft before retrying.');
    } finally {
      setSendingProposal(false);
    }
  };

  const suppressProposalRecipient = async () => {
    if (!proposalDraft) return;
    try {
      await api.post('/api/email/suppress', { email: proposalDraft.recipientEmail });
      setNotice('This recipient has been added to your workspace opt-out list. Future proposal sends to this address are blocked.');
      setSendConfirmed(false);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Could not save the recipient opt-out.');
    }
  };

  useEffect(() => {
    if (user && active === 'Proposal studio') void checkEmailSetup();
  }, [active, user?.userId]);

  const enrichWebsite = async () => {
    if (!crawlUrl.trim()) { setErrorMsg('Enter a public business website URL to enrich.'); return; }
    if (!crawlPermission) { setErrorMsg('Confirm that you are authorized to crawl this website before continuing.'); return; }
    setCrawlLoading(true); setErrorMsg(''); setNotice('');
    try {
      const response = await api.post('/api/enrichment/website', {
        url: crawlUrl.trim(),
        permissionConfirmed: crawlPermission,
      });
      const pages = response.data.crawl?.pages || [];
      if (!pages.length) throw new Error('The crawler returned no readable page content.');
      setCrawlResults(pages);
      setNotice('Website content retrieved from Apify and saved to your private workspace.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Website enrichment failed. No placeholder results were added.');
    } finally {
      setCrawlLoading(false);
    }
  };

  const discoverBusinesses = async () => {
    if (!discoveryTerm.trim() || !oppLocation.trim()) {
      setErrorMsg('Enter an industry and a city or country before searching.');
      return;
    }
    if (!searchPermission) {
      setErrorMsg('Confirm that you have reviewed the Google Search actor terms and applicable data rules.');
      return;
    }
    setSearchLoading(true); setErrorMsg(''); setNotice('');
    try {
      const response = await api.post('/api/discovery/search', {
        industry: discoveryTerm.trim(),
        location: oppLocation.trim(),
        countryCode: discoveryCountryCode,
        sourcePermissionConfirmed: searchPermission,
      });
      const results = response.data.results || [];
      setOpportunities(previous => [...results, ...previous]);
      setOppKind('business');
      setOppIndustry(discoveryTerm.trim());
      setContactUrlList(results.map((item: Opportunity) => item.sourceUrl).filter((value: string) => /^https?:\/\//i.test(value)).join('\n'));
      setNotice('Saved ' + results.length + ' real organic search result(s). Review each business and source before contacting it.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Google Search discovery failed. No sample businesses were added.');
    } finally {
      setSearchLoading(false);
    }
  };

  const enrichContacts = async () => {
    const urls = Array.from(new Set(contactUrlList.split(String.fromCharCode(10)).flatMap(line => line.split(/[;,]+/)).map(value => value.trim()).filter(Boolean))).slice(0, 50);
    if (!urls.length) { setErrorMsg('Paste one or more business website URLs to enrich.'); return; }
    if (!contactPermission) { setErrorMsg('Confirm that you are authorized to collect public contact details from these websites.'); return; }
    setContactLoading(true); setErrorMsg(''); setNotice('');
    try {
      const response = await api.post('/api/enrichment/contacts', {
        urls,
        countryCode: discoveryCountryCode.toUpperCase(),
        permissionConfirmed: contactPermission,
      });
      const saved = response.data.prospects || [];
      setProspects(previous => [...saved, ...previous]);
      setContactResults(saved);
      setNotice('Saved ' + saved.length + ' contact-enriched prospect(s) to your private CRM. No emails were sent.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Contact enrichment failed. No placeholder contacts were added.');
    } finally {
      setContactLoading(false);
    }
  };

  const startCheckout = async (planId: string, paymentMethod: 'card' | 'mpesa') => {
    setLoading(true); setErrorMsg('');
    try {
      const response = await api.post('/api/billing/checkout', { plan: planId, currency, paymentMethod });
      window.location.assign(response.data.url);
    } catch (err) { setErrorMsg(err instanceof Error ? err.message : 'Paystack checkout could not be started.'); setLoading(false); }
  };

  const openPortal = async () => {
    setLoading(true); setErrorMsg('');
    try {
      const response = await api.post('/api/billing/portal');
      window.location.assign(response.data.url);
    } catch (err) { setErrorMsg(err instanceof Error ? err.message : 'Billing portal is unavailable.'); setLoading(false); }
  };

  const exportReport = () => {
    if (!audit) return;
    const lines = ['LISTINGCRAFT BUSINESS AUDIT', audit.businessName, audit.website, audit.location, 'Website health score: ' + audit.score + '/100', audit.summary, '', 'FINDINGS', ...audit.findings.map(f => '[' + f.severity + '] ' + f.title + '\nEvidence: ' + f.evidence + '\nAction: ' + f.recommendation + '\n'), '', 'STRENGTHS', ...audit.strengths.map(s => '- ' + s), '', 'Scope: Public website content only. Not a financial, legal or full operational audit.'];
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = 'listingcraft-audit.txt'; link.click(); URL.revokeObjectURL(link.href);
  };

  const visibleFindings = useMemo(() => audit?.findings.filter(f => filter === 'All' || f.severity === filter) || [], [audit, filter]);
  const nav = [
    { name: 'Overview', icon: LayoutDashboard }, { name: 'Discovery', icon: Search },
    { name: 'Proposal studio', icon: FileText },
    { name: 'Property opportunities', icon: Building2 }, { name: 'Trust intelligence', icon: ShieldCheck },
    { name: 'New audit', icon: FileSearch }, { name: 'Audit history', icon: Clock3 },
    { name: 'Prospects', icon: Users }, { name: 'Automation centre', icon: Activity }, { name: 'Billing', icon: Zap },
  ];

  if (authLoading) return <div className="auth-loading"><div className="brand-mark"><Target size={23}/></div><strong>Loading ListingCraft…</strong></div>;

  if (!user) return <div className="login-shell">
    <div className="login-nav"><div className="brand"><div className="brand-mark"><span className="brand-monogram">LC</span></div><span>Listing<span className="brand-light">Craft</span></span></div><span>AI BUSINESS AUDIT PLATFORM</span></div>
    <div className="login-hero"><div className="login-copy"><div className="eyebrow">BUSINESS INTELLIGENCE, MADE ACTIONABLE</div><h1>Find the gaps.<br/><em>Unlock the growth.</em></h1><p>Find business opportunities, review public websites, uncover conversion and trust gaps, then organize promising companies in your lead pipeline.</p><div className="login-points"><span><Check size={15}/> Evidence-led website audits</span><span><Check size={15}/> Private customer workspaces</span><span><Check size={15}/> Business lead tracking and audit reports</span></div><button className="primary-button login-button" disabled={signingIn} onClick={signIn}>{signingIn ? 'Opening secure sign-in…' : 'Create account / Sign in'} <ArrowUpRight size={17}/></button><small>Secure sign-in · Email and supported identity providers</small>{errorMsg && <div className="error-box">{errorMsg}</div>}</div><div className="login-art"><div className="login-orbit one"/><div className="login-orbit two"/><div className="login-center"><Target size={48}/></div><div className="login-float lf-one"><Activity size={15}/> Website health</div><div className="login-float lf-two"><TrendingUp size={15}/> Growth opportunities</div><div className="login-float lf-three"><ShieldCheck size={15}/> Trust signals</div></div></div>
    <div className="login-bottom"><span>© 2026 ListingCraft</span><span>Global · English-first launch</span><span>Audit public information responsibly.</span></div>
  </div>;

  const currentPlan = plan?.planName || 'Free';
  const used = plan?.usage.count || 0;
  const limit = plan?.usage.limit || 3;

  return <div className="shell">
    <aside className={'sidebar ' + (mobileOpen ? 'open' : '')}>
      <div className="brand"><div className="brand-mark"><span className="brand-monogram">LC</span></div><span>Listing<span className="brand-light">Craft</span></span><button className="mobile-close" onClick={() => setMobileOpen(false)}><X size={18}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map(n => <button key={n.name} className={'nav-item ' + (active === n.name || active === 'Audit report' && n.name === 'Overview' ? 'selected' : '')} onClick={() => change(n.name)}><n.icon size={18}/><span>{n.name}</span>{n.name === 'Audit history' && history.length > 0 && <small>{history.length}</small>}</button>)}</nav>
      <div className="side-divider"/>
      <div className="workspace-label">ACCOUNT</div>
      <button className="nav-item" onClick={() => change('Settings')}><Settings size={18}/><span>Settings</span></button>
      <button className="nav-item" onClick={() => change('Help center')}><LifeBuoy size={18}/><span>Help center</span></button>
      <div className="side-bottom"><div className="upgrade-card"><div className="upgrade-icon"><Sparkles size={16}/></div><strong>{currentPlan} plan</strong><p>{used} of {limit} monthly audits used.</p><button onClick={() => change('Billing')}>Manage subscription <ArrowUpRight size={14}/></button></div><div className="profile"><div className="avatar">{(user.name || user.email || 'LC').slice(0, 2).toUpperCase()}</div><div><strong>{user.name || 'My workspace'}</strong><span>{user.email || 'Signed in'}</span></div><button className="profile-signout" title="Sign out" onClick={signOut}><LogOut size={15}/></button></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><button className="menu-button" onClick={() => setMobileOpen(true)}><Menu size={20}/></button><div className="crumb">Workspace <span>/</span> <b>{active}</b></div><div className="top-actions"><span className="region"><Globe2 size={15}/> Global · English-first</span><span className="plan-chip">{currentPlan}</span><div className="avatar small">{(user.name || user.email || 'LC').slice(0, 2).toUpperCase()}</div></div></header>
      <div className="content">
        {notice && <div className="notice-box"><Check size={15}/>{notice}<button onClick={() => setNotice('')}><X size={14}/></button></div>}
        {errorMsg && <div className="error-box global-error">{errorMsg}<button onClick={() => setErrorMsg('')}><X size={14}/></button></div>}

        {(active === 'Overview' || active === 'Audit report') && <>{audit && active === 'Audit report' ? <>
          <div className="report-head"><div><div className="report-meta"><span className="status-dot"/> AUDIT COMPLETE <span>·</span> {new Date(audit.scannedAt).toLocaleDateString()}</div><h2>{audit.businessName}</h2><div className="site-line"><Globe2 size={14}/>{audit.website}<span>·</span>{audit.location}</div></div><button className="outline-button" onClick={exportReport}><Download size={16}/> Export report</button></div>
          <div className="score-grid"><div className="score-card"><div className="card-label">WEBSITE HEALTH SCORE</div><div className="score-line"><div className="score-ring" style={{'--score': audit.score} as React.CSSProperties}><div><strong>{audit.score}</strong><span>/100</span></div></div><div><strong className="score-state">{scoreLabel(audit.score)}</strong><p>Based on accessible public website signals.</p></div></div></div><div className="metric-card"><div className="metric-top"><span>High priority</span><span className="metric-icon red"><Activity size={17}/></span></div><strong>{audit.findings.filter(f => f.severity === 'High').length}</strong><small>Items to address</small></div><div className="metric-card"><div className="metric-top"><span>Opportunities</span><span className="metric-icon blue"><TrendingUp size={17}/></span></div><strong>{audit.findings.length}</strong><small>Recommendations</small></div><div className="metric-card"><div className="metric-top"><span>Strengths</span><span className="metric-icon green"><BadgeCheck size={17}/></span></div><strong>{audit.strengths.length}</strong><small>Positive signals</small></div></div>
          <div className="section-heading"><div><h3>Recommended actions</h3><p>Evidence-led findings from the public website.</p></div><select value={filter} onChange={e => setFilter(e.target.value)}><option>All</option><option>High</option><option>Medium</option><option>Low</option></select></div>
          <div className="finding-list">{visibleFindings.map((f, i) => <div className="finding" key={i}><div className={'severity ' + f.severity.toLowerCase()}>{f.severity === 'High' ? '!' : f.severity === 'Medium' ? '•' : 'i'}</div><div className="finding-body"><div className="finding-title-row"><div><span className="category">{f.category}</span><h4>{f.title}</h4></div><span className={'priority-tag ' + f.severity.toLowerCase()}>{f.severity} priority</span></div><p>{f.evidence}</p><div className="recommendation"><Check size={15}/><span><b>Recommended action:</b> {f.recommendation}</span></div></div></div>)}{!visibleFindings.length && <div className="empty-state">No findings in this category.</div>}</div>
          <div className="bottom-panels"><div className="panel"><h3>What's working</h3>{audit.strengths.map((s, i) => <div className="strength" key={i}><Check size={15}/>{s}</div>)}</div><div className="panel"><h3>Audit scope</h3><p>{audit.summary}</p><div className="scope-note"><ShieldCheck size={16}/> Public website content only. External listings, private operations and actual revenue are not independently verified.</div></div></div>
        </> : <><div className="welcome-row"><div><div className="eyebrow">BUSINESS INTELLIGENCE WORKSPACE</div><h1>Find the gaps. Unlock growth.</h1><p>Find potential customers, review their websites, and organize your business leads in one workspace.</p></div><button className="primary-button" onClick={() => change('New audit')}><Plus size={17}/> New audit</button></div>
          <div className="hero-card"><div className="hero-copy"><div className="hero-pill"><Sparkles size={13}/> YOUR AI AUDIT ASSISTANT</div><h2>Turn a website into<br/><em>a growth action plan.</em></h2><p>Start with a business website, identify practical improvement opportunities, then save the company as a lead to manage your follow-up.</p><button className="hero-cta" onClick={() => change('New audit')}>Start a business audit <ArrowUpRight size={16}/></button><div className="hero-trust"><span><Check size={13}/> Evidence-led findings</span><span><Check size={13}/> Actionable recommendations</span></div></div><div className="hero-visual"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="visual-core"><Target size={43}/></div><div className="float-chip chip-a"><span className="chip-dot red-dot"/> Visibility gaps</div><div className="float-chip chip-b"><TrendingUp size={14}/> Growth opportunities</div><div className="float-chip chip-c"><ShieldCheck size={14}/> Trust signals</div></div></div>
          <div className="workflow-strip"><div className="workflow-step"><span>01</span><div><b>Find a business</b><small>Enter a company website in New audit.</small></div></div><div className="workflow-step"><span>02</span><div><b>Discover opportunities</b><small>Review website gaps and recommendations.</small></div></div><div className="workflow-step"><span>03</span><div><b>Manage your lead</b><small>Save contact details and track follow-up in Business prospects.</small></div></div></div><div className="overview-stats"><div className="stat-box"><span>Saved audits</span><strong>{history.length}</strong><small><FileSearch size={13}/> Your account history</small></div><div className="stat-box"><span>Average health score</span><strong>{history.length ? Math.round(history.reduce((sum, item) => sum + item.score, 0) / history.length) : '—'}</strong><small><BarChart3 size={13}/> Across saved audits</small></div><div className="stat-box"><span>Monthly usage</span><strong>{used}/{limit}</strong><small><Activity size={13}/> {currentPlan} allowance</small></div></div>
          <div className="section-heading"><div><h3>Recent audits</h3><p>Your latest business website reviews.</p></div><button className="text-button" onClick={() => change('Audit history')}>View history <ArrowUpRight size={14}/></button></div>
          {history.length ? <div className="history-list">{history.slice(0, 5).map(item => <button className="history-row" key={item.id} onClick={() => saveAudit(item)}><div className="history-icon"><Building2 size={18}/></div><div className="history-name"><b>{item.businessName}</b><span>{item.website}</span></div><span className="history-score">{item.score}/100</span><span className="history-date">{new Date(item.scannedAt).toLocaleDateString()}</span><ExternalLink size={15}/></button>)}</div> : <div className="empty-state">No audits yet. Run your first scan to start building your business intelligence workspace.</div>}
        </>}</>}

        {active === 'New audit' && <><div className="page-intro"><div className="eyebrow">AI-POWERED WEBSITE REVIEW</div><h1>Start a new business audit</h1><p>Inspect accessible public website content and return evidence-based findings.</p></div><div className="scan-layout"><div className="scan-card"><div className="scan-card-title"><div className="scan-symbol"><Search size={20}/></div><div><h2>Business details</h2><p>Enter a public website to begin.</p></div></div><label>Business name <span>OPTIONAL</span></label><input value={business} onChange={e => setBusiness(e.target.value)} placeholder="e.g. Northstar Dental Studio"/><label>Website URL <b>*</b></label><div className="url-input"><Globe2 size={17}/><input value={url} onChange={e => setUrl(e.target.value)} onKeyDown={e => e.key === 'Enter' && runScan()} placeholder="https://example.com"/></div><label>City / region <span>OPTIONAL</span></label><input value={location} onChange={e => setLocation(e.target.value)} placeholder="e.g. Austin, Texas or Berlin, Germany"/><button className="primary-button scan-submit" disabled={loading} onClick={runScan}>{loading ? 'Analyzing website…' : <><Sparkles size={17}/> Run AI audit</>}</button><div className="privacy-line"><ShieldCheck size={14}/> Public websites only. No login-protected pages are accessed.</div><div className="usage-hint">Monthly allowance: {used} of {limit} audits used on your {currentPlan} plan.</div></div><div className="scan-aside"><div className="aside-title">WHAT YOUR AUDIT CHECKS</div>{[{icon:Globe2,title:'Website presence',desc:'Accessible content, contact details and business clarity.'},{icon:Target,title:'Conversion signals',desc:'Calls to action, enquiry paths and booking cues.'},{icon:ShieldCheck,title:'Trust cues',desc:'Testimonials, credibility and customer reassurance.'},{icon:ListChecks,title:'Action plan',desc:'Prioritized recommendations with supporting evidence.'}].map((x, i) => <div className="check-item" key={i}><div className="check-icon"><x.icon size={17}/></div><div><b>{x.title}</b><p>{x.desc}</p></div></div>)}<div className="aside-disclaimer">This release audits public website content. It does not verify private operations or actual revenue.</div></div></div></>}

        {active === 'Audit history' && <><div className="page-intro"><div className="eyebrow">YOUR ACCOUNT</div><h1>Audit history</h1><p>Your saved reports, available across sessions when you sign in.</p></div><div className="history-list full">{history.map(item => <button className="history-row" key={item.id} onClick={() => saveAudit(item)}><div className="history-icon"><Building2 size={18}/></div><div className="history-name"><b>{item.businessName}</b><span>{item.website}</span></div><span className="history-score">{item.score}/100</span><span className="history-date">{new Date(item.scannedAt).toLocaleDateString()}</span><ExternalLink size={15}/></button>)}{!history.length && <div className="empty-state">Your completed audits will appear here.</div>}</div></>}

        {active === 'Prospects' && <><div className="page-intro"><div className="eyebrow">AGENCY WORKSPACE</div><h1>Business prospects & outreach</h1><p>Build a lead list of companies that may benefit from website improvements. Save contact details, notes and follow-up context here.</p></div><div className="prospect-layout"><div className="scan-card"><div className="scan-card-title"><div className="scan-symbol"><Users size={20}/></div><div><h2>Add a prospect</h2><p>Save a company you have identified through research or a website audit.</p></div></div><div className="outreach-note"><b>What you can do here today</b><span>Store business names, websites, contact emails and follow-up notes. You can open a saved website or email address in your own tools. ListingCraft does not send emails or place calls yet.</span></div><label>Business name *</label><input value={prospectName} onChange={e => setProspectName(e.target.value)} placeholder="Business name"/><label>Website</label><input value={prospectWebsite} onChange={e => setProspectWebsite(e.target.value)} placeholder="https://example.com"/><label>Contact email</label><input value={prospectEmail} onChange={e => setProspectEmail(e.target.value)} placeholder="contact@example.com" type="email"/><label>Notes</label><textarea value={prospectNotes} onChange={e => setProspectNotes(e.target.value)} placeholder="Potential opportunity, contact notes, follow-up context…"/><button className="primary-button scan-submit" disabled={loading} onClick={addProspect}><Plus size={16}/> Save prospect</button></div><div className="prospect-list"><div className="section-heading"><div><h3>Your lead pipeline</h3><p>{prospects.length} businesses saved for follow-up.</p></div></div>{prospects.map(p => <div className="prospect-card" key={p.id}><div className="prospect-top"><b>{p.businessName}</b><span className="priority-tag low">{p.status}</span></div>{p.website && <a href={p.website} target="_blank" rel="noreferrer">{p.website}</a>}{p.contactEmail && <span>{p.contactEmail}</span>}{p.notes && <p>{p.notes}</p>}<small>Added {new Date(p.createdAt).toLocaleDateString()}</small></div>)}{!prospects.length && <div className="empty-state">Your saved business prospects will appear here.</div>}</div></div></>}

        {active === 'Discovery' && <><div className="page-intro"><div className="eyebrow">GLOBAL · ENGLISH-FIRST MARKETS</div><h1>Discover business opportunities</h1><p>Build a prospecting pipeline across industries and countries. Search public sources, review each candidate, then save only the opportunities you have checked.</p></div><div className="discovery-banner"><div><span className="banner-kicker">BUSINESS DISCOVERY</span><h2>Find businesses with room to grow.</h2><p>Start with a country, city and industry. ListingCraft does not invent search results or scrape restricted directories; use the public search links below, then record verified candidates.</p></div><div className="discovery-globe"><Globe2 size={38}/><b>Global reach</b><small>English-first launch</small></div></div>
<div className="integration-panel">
  <div className="integration-panel-head">
    <div><span className="banner-kicker">CONNECTED PROVIDER WORKFLOW</span><h2>Live data connectors</h2><p>Real actor runs only. Failed or blocked runs never create sample leads.</p></div>
    <span className="priority-tag low">50 max businesses / run</span>
  </div>
  <div className="provider-grid">
    <div className="provider-card">
      <div className="provider-title"><b>Google Maps business discovery</b><span className="priority-tag high">Licensing review</span></div>
      <p><code>compass/crawler-google-places</code></p>
      <p>Actor configured with a hard 50-business cap, but execution is blocked until written commercial-use and Google source-rights clearance is recorded. An Apify token is not a data licence.</p>
      <a href="https://apify.com/compass/crawler-google-places" target="_blank" rel="noreferrer">Review actor terms <ExternalLink size={13}/></a>
    </div>
    <div className="provider-card">
      <div className="provider-title"><b>Google Search business discovery</b><span className="priority-tag low">Configured · not live-tested</span></div>
      <p><code>apify/google-search-scraper</code></p>
      <p>Searches public Google result pages and saves up to 50 unique organic business websites per run. Review Google’s terms and applicable privacy rules before using results commercially; search access is not a licence to reuse every destination’s content.</p>
      <a href="https://apify.com/apify/google-search-scraper" target="_blank" rel="noreferrer">Review actor and pricing <ExternalLink size={13}/></a>
    </div>
    <div className="provider-card">
      <div className="provider-title"><b>Website content enrichment</b><span className="priority-tag low">Available with permission</span></div>
      <p><code>apify/website-content-crawler</code></p>
      <p>Provide a business website you are authorized to crawl. The run is limited to 3 pages and respects robots.txt.</p>
      <label>Business website URL</label>
      <input value={crawlUrl} onChange={e => setCrawlUrl(e.target.value)} placeholder="https://business.example"/>
      <label className="permission-check"><input type="checkbox" checked={crawlPermission} onChange={e => setCrawlPermission(e.target.checked)}/> I confirm I am authorized to crawl this website and have reviewed its published access policies.</label>
      <button className="primary-button scan-submit" disabled={crawlLoading || !crawlUrl.trim() || !crawlPermission} onClick={enrichWebsite}>{crawlLoading ? 'Crawling website…' : 'Enrich website with real content'} <ArrowUpRight size={15}/></button>
    </div>
    <div className="provider-card">
      <div className="provider-title"><b>Contact details enrichment</b><span className="priority-tag low">Configured · not live-tested</span></div>
      <p><code>data_wiki/contact-details-scraper</code></p>
      <p>Finds publicly published company emails, phone numbers and social profiles. Paste up to 50 websites; the Actor’s published free tier processes up to 10 results per run. Email addresses are not automatically contacted.</p>
      <label>Business website URLs (one per line)</label>
      <textarea value={contactUrlList} onChange={e => setContactUrlList(e.target.value)} rows={4} placeholder="https://business-one.example&#10;https://business-two.example"/>
      <label className="permission-check"><input type="checkbox" checked={contactPermission} onChange={e => setContactPermission(e.target.checked)}/> I confirm I have reviewed the websites’ published policies and am authorized to collect their public business contact details.</label>
      <button className="primary-button scan-submit" disabled={contactLoading || !contactUrlList.trim() || !contactPermission} onClick={enrichContacts}>{contactLoading ? 'Finding public contact details…' : 'Enrich up to 10 websites'} <ArrowUpRight size={15}/></button>
    </div>
    <div className="provider-card">
      <div className="provider-title"><b>Property listing discovery</b><span className="priority-tag high">Licensing review</span></div>
      <p><code>maxcopell/zillow-scraper</code></p>
      <p>Retained as the property actor. Execution remains blocked until Zillow terms and multi-customer commercial-use rights are cleared. Property data is not redistributed by default.</p>
      <a href="https://apify.com/maxcopell/zillow-scraper" target="_blank" rel="noreferrer">Review actor details <ExternalLink size={13}/></a>
    </div>
  </div>
  {contactResults.length > 0 && <div className="crawl-results"><div className="section-heading"><div><h3>Contact enrichment results</h3><p>{contactResults.length} real prospect record(s) saved to your CRM. No outreach was sent.</p></div></div>{contactResults.map((item, index) => <div className="crawl-result" key={item.website + index}><b>{item.businessName}</b><a href={item.website} target="_blank" rel="noreferrer">{item.website}</a>{item.contactEmail && <p>Public email: {item.contactEmail}</p>}<p>{item.notes}</p></div>)}</div>}
  {crawlResults.length > 0 && <div className="crawl-results"><div className="section-heading"><div><h3>Retrieved website content</h3><p>{crawlResults.length} real page(s) returned by the actor. Evidence only; not a trust certification.</p></div></div>{crawlResults.map((page, index) => <div className="crawl-result" key={page.url + index}><b>{page.title || page.url}</b><a href={page.url} target="_blank" rel="noreferrer">{page.url}</a><p>{page.text.slice(0, 1200)}{page.text.length > 1200 ? '…' : ''}</p></div>)}</div>}
</div>
<div className="opportunity-grid"><div className="scan-card"><div className="scan-card-title"><div className="scan-symbol"><Search size={20}/></div><div><h2>Build a business search</h2><p>Generate a targeted public web search.</p></div></div><label>Industry / business type</label><input value={discoveryTerm} onChange={e => setDiscoveryTerm(e.target.value)} placeholder="e.g. plumbers, salons, car dealers, hotels"/><label>Country or city</label><input value={oppLocation} onChange={e => setOppLocation(e.target.value)} placeholder="e.g. London, United Kingdom"/><div className="industry-chips">{['Plumbers','Electricians','Mechanics','Car dealers','Salons','Restaurants','Hotels','Realtors','Contractors'].map(term => <button key={term} onClick={() => setDiscoveryTerm(term)}>{term}</button>)}</div><label>Google results country</label>
<select value={discoveryCountryCode} onChange={e => setDiscoveryCountryCode(e.target.value)}>
  <option value="ke">Kenya</option><option value="gb">United Kingdom</option><option value="us">United States</option><option value="ca">Canada</option><option value="au">Australia</option><option value="za">South Africa</option><option value="in">India</option><option value="ph">Philippines</option>
</select>
<label className="permission-check"><input type="checkbox" checked={searchPermission} onChange={e => setSearchPermission(e.target.checked)}/> I have reviewed the Google Search actor terms and confirm this search and intended data use are appropriate.</label>
<button className="primary-button scan-submit" disabled={searchLoading || !discoveryTerm.trim() || !oppLocation.trim() || !searchPermission} onClick={discoverBusinesses}>{searchLoading ? 'Searching Google…' : 'Discover up to 50 businesses'} <ArrowUpRight size={15}/></button><p className="privacy-line">Real organic results are saved in your workspace. Review each source and verify details before contacting a business.</p></div><div className="scan-aside"><div className="aside-title">RECOMMENDED WORKFLOW</div>{[{title:'Search by niche',desc:'Target a trade, service or business category in a specific city.'},{title:'Review public evidence',desc:'Check the business website, contact page and public information.'},{title:'Run a website audit',desc:'Use New audit to inspect accessible website content.'},{title:'Save the opportunity',desc:'Record the business in the workspace and qualify it in your pipeline.'}].map((x,i) => <div className="check-item" key={i}><div className="check-icon"><Check size={16}/></div><div><b>{x.title}</b><p>{x.desc}</p></div></div>)}</div></div><div className="scan-card business-save-card"><div className="scan-card-title"><div className="scan-symbol"><Plus size={19}/></div><div><h2>Save a researched business</h2><p>Add a candidate after checking its public source.</p></div></div><label>Business name *</label><input value={oppTitle} onChange={e => setOppTitle(e.target.value)} placeholder="Business name"/><label>City / country *</label><input value={oppLocation} onChange={e => setOppLocation(e.target.value)} placeholder="City, country"/><label>Industry</label><input value={oppIndustry} onChange={e => setOppIndustry(e.target.value)} placeholder="e.g. plumbing, salon, auto repair"/><label>Website / source URL</label><input value={oppUrl} onChange={e => setOppUrl(e.target.value)} placeholder="https://…"/><label>Evidence and notes</label><textarea value={oppDetails} onChange={e => setOppDetails(e.target.value)} placeholder="What did you verify? What opportunity did you notice?"/><button className="primary-button scan-submit" disabled={loading} onClick={() => saveOpportunity('business')}><Plus size={16}/> Save business opportunity</button></div><div className="section-heading"><div><h3>Saved opportunities</h3><p>{opportunities.filter(o => o.kind === 'business').length} business opportunities in your workspace.</p></div></div><div className="opportunity-list">{opportunities.filter(o => o.kind === 'business').map(o => <div className="opportunity-card" key={o.id}><div><b>{o.title}</b><span>{o.industry || 'Business'} · {o.location}</span>{o.details && <p>{o.details}</p>}</div><span className="priority-tag low">{o.status}</span>{o.sourceUrl && <a href={o.sourceUrl} target="_blank" rel="noreferrer">Open source <ExternalLink size={12}/></a>}</div>)}{!opportunities.some(o => o.kind === 'business') && <div className="empty-state">No saved business opportunities yet. Search a market, review a candidate and add it to your workspace.</div>}</div></>}

        {active === 'Property opportunities' && <><div className="page-intro"><div className="eyebrow">REAL ESTATE INTELLIGENCE</div><h1>Property opportunities</h1><p>Track listing leads from URLs you provide, CSVs you review or authorized MLS / partner feeds as they become available.</p></div><div className="property-notice"><ShieldCheck size={18}/><div><b>Source-responsible property data</b><span>ListingCraft does not scrape Zillow or Redfin. Use a listing URL as a reference, your own authorized data, or an approved MLS / RESO / partner feed. Confirm permissions before importing or redistributing listing details.</span></div></div><div className="opportunity-grid"><div className="scan-card"><div className="scan-card-title"><div className="scan-symbol"><Building2 size={20}/></div><div><h2>Add a property lead</h2><p>Save a listing reference and your own notes.</p></div></div><label>Property / listing title *</label><input value={oppTitle} onChange={e => setOppTitle(e.target.value)} placeholder="e.g. 2-bedroom apartment in Manchester"/><label>Location *</label><input value={oppLocation} onChange={e => setOppLocation(e.target.value)} placeholder="City, region, country"/><label>Property type / opportunity</label><input value={oppIndustry} onChange={e => setOppIndustry(e.target.value)} placeholder="Residential, commercial, rental, land…"/><label>Listing URL / authorized source</label><input value={oppUrl} onChange={e => setOppUrl(e.target.value)} placeholder="https://…"/><label>Notes and source permissions</label><textarea value={oppDetails} onChange={e => setOppDetails(e.target.value)} placeholder="Asking price if verified, agent details, date checked, authorization notes…"/><button className="primary-button scan-submit" disabled={loading} onClick={() => saveOpportunity('property')}><Plus size={16}/> Save property opportunity</button></div><div className="scan-aside"><div className="aside-title">PROPERTY CONFIDENCE CHECKS</div>{[{title:'Source provenance',desc:'Is the source authorized and clearly identified?'},{title:'Freshness',desc:'When was the listing last checked by you or your feed?'},{title:'Detail consistency',desc:'Do price, location and property details agree across permitted sources?'},{title:'Authorization',desc:'Is the agent, owner or data provider authorized to share the listing?'},{title:'Duplicate review',desc:'Could this be the same property listed more than once?'}].map((x,i) => <div className="check-item" key={i}><div className="check-icon"><ShieldCheck size={16}/></div><div><b>{x.title}</b><p>{x.desc}</p></div></div>)}</div></div><div className="section-heading"><div><h3>Property pipeline</h3><p>{opportunities.filter(o => o.kind === 'property').length} property references saved.</p></div></div><div className="opportunity-list">{opportunities.filter(o => o.kind === 'property').map(o => <div className="opportunity-card" key={o.id}><div><b>{o.title}</b><span>{o.industry || 'Property'} · {o.location}</span>{o.details && <p>{o.details}</p>}</div><span className="priority-tag low">Reference saved · not verified</span>{o.sourceUrl && <a href={o.sourceUrl} target="_blank" rel="noreferrer">Open listing <ExternalLink size={12}/></a>}</div>)}{!opportunities.some(o => o.kind === 'property') && <div className="empty-state">No property references saved yet. Add a listing URL and record its source and date checked.</div>}</div></>}

        {active === 'Trust intelligence' && <><div className="page-intro"><div className="eyebrow">EVIDENCE-LED SCORING</div><h1>Trust intelligence</h1><p>Understand visible signals and missing evidence without presenting an automated score as certification.</p></div><div className="trust-score-grid"><div className="panel"><div className="trust-icon"><ShieldCheck size={22}/></div><h3>Business Trust Score</h3><p>Designed for public business evidence: HTTPS and site security signals, contact and identity clarity, review reputation where a permitted source is connected, consistency of business information, transparency and website usability.</p><div className="trust-tags"><span>Evidence attached</span><span>Date checked</span><span>Missing evidence</span></div></div><div className="panel"><div className="trust-icon property"><Building2 size={22}/></div><h3>Property Listing Confidence</h3><p>Designed for property provenance: authorized source, listing freshness, detail consistency, agent / owner authorization and duplicate review. Unverified claims remain clearly labelled.</p><div className="trust-tags"><span>Source provenance</span><span>Freshness</span><span>Authorization</span></div></div></div><div className="property-notice"><Activity size={18}/><div><b>Scoring status: framework defined, full verification integrations not yet connected.</b><span>Current website audits score accessible page content and conversion readiness. A full cross-source trust score will only be calculated when each evidence source is available, with its source and timestamp shown.</span></div></div></>}

        {active === 'Automation centre' && <AutomationCentre />}

        {active === 'Proposal studio' && <>
          <div className="page-intro">
            <div className="eyebrow">AUDIT-LED CLIENT PROPOSALS</div>
            <h1>Proposal studio</h1>
            <p>Prepare a personalized first-contact draft from evidence in one of your saved website audits.</p>
          </div>
          <div className="scan-layout">
            <div className="scan-card">
              <div className="scan-card-title">
                <div className="scan-symbol"><FileText size={20}/></div>
                <div><h2>Generate a proposal draft</h2><p>Only saved audit findings are used as evidence.</p></div>
              </div>
              <label>Source website audit *</label>
              <select value={proposalAuditId || history[0]?.id || ''} onChange={e => setProposalAuditId(e.target.value)}>
                <option value="">Select a saved audit</option>
                {history.map(item => <option key={item.id} value={item.id}>{item.businessName} · {new Date(item.scannedAt).toLocaleDateString()}</option>)}
              </select>
              <label>Recipient email *</label>
              <input type="email" value={proposalEmail} onChange={e => setProposalEmail(e.target.value)} placeholder="owner@business.com"/>
              <label>Your service / offer <span>OPTIONAL</span></label>
              <textarea value={proposalOffer} onChange={e => setProposalOffer(e.target.value)} placeholder="Describe the service you want to offer, e.g. website redesign, booking integration, local SEO support…"/>
              <button className="primary-button scan-submit" disabled={proposalLoading || history.length === 0 || !proposalEmail.trim()} onClick={generateProposal}>
                {proposalLoading ? 'Preparing evidence-based draft…' : 'Generate proposal draft'} <ArrowUpRight size={15}/>
              </button>
              <div className="privacy-line"><ShieldCheck size={14}/> Drafts are private. Emails are only submitted after your explicit approval.</div>
            </div>
            <div className="scan-aside">
              <div className="aside-title">DRAFTING SAFEGUARDS</div>
              <div className="check-item"><div className="check-icon"><FileSearch size={17}/></div><div><b>Uses a saved audit</b><p>Recommendations are grounded in the selected website findings.</p></div></div>
              <div className="check-item"><div className="check-icon"><ShieldCheck size={17}/></div><div><b>No invented performance claims</b><p>No fabricated revenue losses, ROI, deadlines or guarantees.</p></div></div>
              <div className="check-item"><div className="check-icon"><Users size={17}/></div><div><b>Human approval first</b><p>Review and edit the draft before using it with a prospect.</p></div></div>
              <div className="aside-disclaimer">Email sending uses your verified sender identity. Recipients can reply UNSUBSCRIBE; record requests using the opt-out control on each draft. Provider acceptance is not proof of inbox delivery.</div>
            </div>
          </div>
          {proposalDraft && <div className="panel settings-panel">
            <div className="section-heading"><div><h3>{proposalDraft.businessName}</h3><p>Draft saved · {new Date(proposalDraft.createdAt).toLocaleString()}</p></div><span className="priority-tag low">{proposalDraft.status}</span></div>
            <p><b>To:</b> {proposalDraft.recipientEmail}</p>
            <p><b>Subject:</b> {proposalDraft.subject}</p>
            <p><b>Executive summary:</b> {proposalDraft.executiveSummary}</p>
            <p><b>Proposed solution:</b> {proposalDraft.proposedSolution}</p>
            <div className="crawl-result"><b>Email body</b><p>{proposalDraft.emailBody}</p></div>
            <button className="outline-button" onClick={() => navigator.clipboard?.writeText('Subject: ' + proposalDraft.subject + '\\n\\n' + proposalDraft.emailBody)}>Copy draft text</button>
            {proposalDraft.status !== 'Accepted' && <div className="outreach-note">
              <b>Email delivery approval</b>
              <span>Confirm that you have a lawful basis to contact this business, the message is relevant to its business role, and the recipient has not previously opted out. ListingCraft limits sends to 10 per workspace per day.</span>
              <label className="permission-check"><input type="checkbox" checked={sendConfirmed} onChange={e => setSendConfirmed(e.target.checked)}/> I reviewed this exact message and confirm the recipient has not opted out.</label>
              <button className="primary-button" disabled={!emailSetup.configured || !sendConfirmed || sendingProposal || emailSetupLoading} onClick={sendProposal}>
                {sendingProposal ? 'Submitting to SendGrid…' : 'Send this email'} <ArrowUpRight size={15}/>
              </button>
              {!emailSetup.configured && <p className="email-setup-warning">Email setup is incomplete. Complete the secure sender configuration, then check again. {emailSetup.missing.join(', ')}</p>}
              <button className="outline-button" onClick={checkEmailSetup} disabled={emailSetupLoading}>{emailSetupLoading ? 'Checking…' : 'Refresh email setup'}</button>
              <button className="outline-button" onClick={suppressProposalRecipient}>Mark recipient opted out</button>
            </div>}
            {proposalDraft.status === 'Accepted' && <div className="notice-box">
              <Check size={15}/> Accepted by SendGrid on {proposalDraft.acceptedAt ? new Date(proposalDraft.acceptedAt).toLocaleString() : 'submission'}. Inbox delivery is not confirmed.
            </div>}
          </div>}
          <div className="section-heading"><div><h3>Saved proposal drafts</h3><p>{proposals.length} draft(s) in your private workspace.</p></div></div>
          <div className="opportunity-list">
            {proposals.map(item => <button className="history-row" key={item.id} onClick={() => setProposalDraft(item)}>
              <div className="history-icon"><FileText size={17}/></div>
              <div className="history-name"><b>{item.businessName}</b><span>{item.subject} · {item.recipientEmail}</span></div>
              <span className="priority-tag low">{item.status}</span>
              <span className="history-date">{new Date(item.createdAt).toLocaleDateString()}</span>
            </button>)}
            {!proposals.length && <div className="empty-state">No proposal drafts yet. Select a saved audit to prepare your first proposal.</div>}
          </div>
        </>}

        {active === 'Billing' && <><div className="page-intro"><div className="eyebrow">SUBSCRIPTION & USAGE</div><h1>Plans that grow with your business.</h1><p>Choose the audit volume that fits your business. Payments are securely processed by Paystack.</p><p className="pricing-note">All ListingCraft checkout prices are shown and collected in Kenyan shillings (KES).</p></div><div className="billing-current"><div><span>YOUR CURRENT PLAN</span><h2>{currentPlan}</h2><p>{plan?.subscriptionStatus || 'inactive'} · {used} of {limit} audits used this month</p></div>{plan?.hasCustomer && <button className="outline-button" disabled={loading} onClick={openPortal}>Manage billing <ExternalLink size={15}/></button>}</div><div className="plans">{planCards.map(p => <div className={'plan ' + (p.id === plan?.plan ? 'current-plan' : '') + (p.popular ? ' popular' : '')} key={p.id}>{p.popular && <div className="popular-label">MOST POPULAR</div>}{p.id === plan?.plan && <div className="current-label">CURRENT PLAN</div>}<h3>{p.name}</h3><p className="plan-desc">{p.id === 'starter' ? 'For solo consultants and small teams' : p.id === 'growth' ? 'For growing agencies and operators' : 'For established audit agencies'}</p><div className="plan-price">{p.kes}<span>/ month</span></div><div className="plan-scans">{p.scans}</div><button className={p.popular ? 'primary-button plan-button' : 'outline-button plan-button'} disabled={loading || p.id === plan?.plan && plan?.subscriptionStatus === 'active'} onClick={() => startCheckout(p.id, 'card')}>{p.id === plan?.plan && plan?.subscriptionStatus === 'active' ? 'Active plan' : 'Subscribe with card'}</button><button className="outline-button plan-button" disabled={loading || p.id === plan?.plan && plan?.subscriptionStatus === 'active'} onClick={() => startCheckout(p.id, 'mpesa')}>Pay monthly with M-PESA</button><div className="plan-features">{p.features.map(f => <div key={f}><Check size={15}/>{f}</div>)}</div></div>)}</div><p className="pricing-note">All checkout payments are collected in KES through the Kenya Paystack account. Card subscriptions renew automatically. M-PESA payments are manual and activate access for 30 days. Scan allowances reset monthly.</p></>}

        {active === 'Settings' && <><div className="page-intro"><h1>Account settings</h1><p>Your ListingCraft account and workspace.</p></div><div className="panel settings-panel"><h3>Account details</h3><p><b>Email:</b> {user.email || 'Not provided by sign-in provider'}</p><p><b>Workspace ID:</b> {user.userId}</p><p><b>Subscription:</b> {currentPlan}</p><button className="outline-button" onClick={signOut}><LogOut size={15}/> Sign out</button></div><div className="panel settings-panel"><h3>Install ListingCraft</h3><p>On Android, use your browser's Install app option. On iPhone, open the Share menu in Safari and choose Add to Home Screen.</p>{installPrompt && <button className="primary-button" onClick={async () => { await installPrompt.prompt(); setInstallPrompt(null); }}>Install app</button>}</div></>}

        {active === 'Help center' && <><div className="page-intro"><h1>ListingCraft help center</h1><p>How to find, review and manage business leads with ListingCraft.</p></div><div className="panel settings-panel"><h3>How do I find businesses to approach?</h3><p>Research companies in your target market, enter their public website in New audit, review the findings, then save promising companies in Business prospects with contact details and follow-up notes.</p><h3>Can ListingCraft contact businesses for me?</h3><p>Not yet. The current release stores lead details and helps you prepare your approach, but it does not send emails, make calls or automate outreach. You can use the saved contact information in your own email or phone tools.</p><h3>What does a scan analyze?</h3><p>Accessible public website content and AI-detected signals around clarity, conversion, contact details and trust.</p><h3>Are scores verified?</h3><p>No. Scores are automated website assessments, not certification or a guarantee of business performance.</p><h3>How do payments work?</h3><p>Paystack securely processes payments. Card subscriptions renew automatically. M-PESA customers make a new payment each month to renew access.</p><h3>How do I install the mobile app?</h3><p>On Android, choose Install app from the browser menu. On iPhone, use Safari's Share menu and select Add to Home Screen.</p></div></>}
        <footer><span>© 2026 ListingCraft</span><span>Built for better business decisions <span className="footer-dot">·</span> Global · English-first</span></footer>
      </div>
    </main>
    {mobileOpen && <button className="scrim" onClick={() => setMobileOpen(false)} aria-label="Close menu"/>}
  </div>;
}
export default App;