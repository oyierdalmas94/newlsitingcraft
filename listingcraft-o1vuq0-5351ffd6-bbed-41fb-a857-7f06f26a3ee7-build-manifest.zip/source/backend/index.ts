import { router, json, error, ai, db, secrets, requireAuth, isAppDatabaseError } from '@appdeploy/sdk';

type Plan = 'free' | 'starter' | 'growth' | 'agency';
type Profile = {
  userId: string;
  email: string;
  name: string;
  plan: Plan;
  subscriptionStatus: string;
  paystackCustomerCode: string;
  paystackSubscriptionCode: string;
  paymentMethod: 'card' | 'mpesa' | '';
  subscriptionExpiresAt: string;
  lastPaymentReference: string;
  updatedAt: string;
};
type Usage = { month: string; count: number };
const PLAN_LIMITS: Record<Plan, number> = { free: 3, starter: 15, growth: 100, agency: 500 };
const PLAN_PRICES: Record<string, Record<string, number>> = {
  starter: { usd: 2900, kes: 390000 },
  growth: { usd: 7900, kes: 1060000 },
  agency: { usd: 19900, kes: 2690000 },
};
const PLAN_LABELS: Record<Plan, string> = { free: 'Free', starter: 'Starter', growth: 'Growth', agency: 'Agency' };
const MONTH = () => new Date().toISOString().slice(0, 7);
const safeKey = (value: string) => value.replace(/[^a-zA-Z0-9]/g, '').slice(0, 48) || 'unknown';
const auditTable = (userId: string) => 'lc_audits_' + safeKey(userId);
const usageTable = (userId: string) => 'lc_usage_' + safeKey(userId);
const prospectTable = (userId: string) => 'lc_prospects_' + safeKey(userId);
const opportunityTable = (userId: string) => 'lc_opps_' + safeKey(userId);
const proposalTable = (userId: string) => 'lc_proposals_' + safeKey(userId);
type DailyEmailUsage = { day: string; count: number };
const emailUsageTable = (userId: string) => 'lc_email_usage_' + safeKey(userId);
const emailSuppressionTable = (userId: string) => 'lc_email_suppressions_' + safeKey(userId);

async function consumeEmailSend(userId: string, limit = 10): Promise<number> {
  const table = emailUsageTable(userId);
  const day = new Date().toISOString().slice(0, 10);
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const [current] = await db.get<DailyEmailUsage>(table, ['current'], { consistent: true });
    if (!current) {
      const [id] = await db.tx.add(table, [{ id: 'current', day, count: 1 }]);
      if (id) return 1;
      continue;
    }
    const count = current.day === day ? current.count : 0;
    if (count >= limit) return -1;
    const [updated] = await db.tx.update(table, [{
      id: 'current',
      record: { day, count: count + 1 },
      if: { day: current.day, count: current.count },
    }], { patch: true });
    if (updated) return count + 1;
  }
  throw new Error('Another email send is being recorded. Please retry.');
}

function escapeEmailHtml(value: string) {
  return value.replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[char] || char));
}



const discoveryUsageTable = (userId: string) => 'lc_disc_usage_' + safeKey(userId);
const GOOGLE_PLACES_COMMERCIAL_USE_ENABLED = false;
const ZILLOW_COMMERCIAL_USE_ENABLED = false;
const BUSINESS_DISCOVERY_LIMIT = 50;

async function getDiscoveryUsage(userId: string): Promise<Usage> {
  const [usage] = await db.get<Usage>(discoveryUsageTable(userId), ['current'], { consistent: true });
  return usage || { month: MONTH(), count: 0 };
}

async function consumeDiscoveryRun(userId: string, limit: number, month = MONTH()): Promise<number> {
  const table = discoveryUsageTable(userId);
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const [current] = await db.get<Usage>(table, ['current'], { consistent: true });
    if (!current) {
      const [id] = await db.tx.add(table, [{ id: 'current', month, count: 1 }]);
      if (id) return 1;
      continue;
    }
    const count = current.month === month ? current.count : 0;
    if (count >= limit) return -1;
    const [updated] = await db.tx.update(table, [{
      id: 'current',
      record: { month, count: count + 1 },
      if: { month: current.month, count: current.count },
    }], { patch: true });
    if (updated) return count + 1;
  }
  throw new Error('Another discovery run is being recorded. Please retry.');
}

async function refundUsageCounter(
  table: string,
  receiptTable: string,
  reservationId: string,
  reservedMonth: string,
  operation: string
): Promise<boolean> {
  try {
    await db.tx.add(receiptTable, [{
      id: '_catalog',
      purpose: 'usage_refund_receipts',
      createdAt: new Date().toISOString(),
    }]);

    for (let attempt = 0; attempt < 5; attempt += 1) {
      const [current] = await db.get<Usage>(table, ['current'], { consistent: true });
      if (!current || current.month !== reservedMonth || current.count <= 0) return false;

      const receipt = db.tx.add(receiptTable, [{
        id: reservationId,
        month: reservedMonth,
        operation,
        createdAt: new Date().toISOString(),
      }]);
      const usage = db.tx.update(table, [{
        id: 'current',
        record: { month: reservedMonth, count: Math.max(0, current.count - 1) },
        if: { month: current.month, count: current.count },
      }], { patch: true });

      try {
        await db.transact([receipt, usage]);
        return true;
      } catch (err) {
        if (isAppDatabaseError(err)) {
          if (err.code === 'AppDatabaseDuplicateId' || err.code === 'AppDatabaseUnknownOutcome') {
            const [savedReceipt] = await db.get<{ month: string; operation: string }>(
              receiptTable,
              [reservationId],
              { consistent: true }
            );
            if (savedReceipt?.month === reservedMonth && savedReceipt.operation === operation) return true;
            if (err.code === 'AppDatabaseUnknownOutcome') return false;
          }
          if (err.code === 'AppDatabaseConflict' || err.code === 'AppDatabaseConditionFailed') continue;
        }
        throw err;
      }
    }
  } catch (err) {
    console.error('ListingCraft usage refund could not be confirmed', operation, err);
  }
  return false;
}

async function refundDiscoveryRun(userId: string, reservedMonth: string, reservationId: string) {
  return refundUsageCounter(
    discoveryUsageTable(userId),
    'lc_disc_refunds_' + safeKey(userId),
    reservationId,
    reservedMonth,
    'discovery'
  );
}

async function runApifyActor(actorId: string, input: Record<string, unknown>) {
  const token = await secrets.readSecret('APIFY_API_TOKEN');
  const response = await fetch(
    'https://api.apify.com/v2/acts/' + actorId + '/run-sync-get-dataset-items?timeout=120',
    {
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + token,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(input),
    }
  );
  const responseText = await response.text();
  if (!response.ok) {
    throw new Error('Apify actor request failed with HTTP ' + response.status + '.');
  }
  let items: unknown;
  try {
    items = JSON.parse(responseText);
  } catch {
    throw new Error('Apify returned an unreadable dataset response.');
  }
  if (!Array.isArray(items)) {
    throw new Error('Apify did not return a dataset array. No results were saved.');
  }
  return items as Array<Record<string, unknown>>;
}

function validatePublicHttpUrl(value: string): URL | null {
  try {
    const parsed = new URL(value);
    if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password) return null;
    const host = parsed.hostname.toLowerCase();
    if (!host || host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')
      || host.endsWith('.internal') || host === '::1' || host.startsWith('127.')
      || host.startsWith('10.') || host.startsWith('192.168.') || host.startsWith('169.254.')
      || host === '0.0.0.0' || host.startsWith('172.16.') || host.startsWith('172.17.')
      || host.startsWith('172.18.') || host.startsWith('172.19.') || host.startsWith('172.2')
      || host.startsWith('172.30.') || host.startsWith('172.31.')) return null;
    return parsed;
  } catch {
    return null;
  }
}

async function getProfile(userId: string, email = '', name = ''): Promise<Profile> {
  const [saved] = await db.get<Profile>('lc_profiles', [userId], { consistent: true });
  if (saved) {
    const expiry = saved.subscriptionExpiresAt ? Date.parse(saved.subscriptionExpiresAt) : 0;
    if (saved.plan !== 'free' && expiry > 0 && expiry <= Date.now()
      && (saved.paymentMethod === 'mpesa' || saved.subscriptionStatus === 'non_renewing')) {
      await updateProfile(userId, { plan: 'free', subscriptionStatus: 'expired' });
      return { ...saved, plan: 'free', subscriptionStatus: 'expired' };
    }
    return saved;
  }
  const initial: Profile = {
    userId,
    email,
    name,
    plan: 'free',
    subscriptionStatus: 'inactive',
    paystackCustomerCode: '',
    paystackSubscriptionCode: '',
    paymentMethod: '',
    subscriptionExpiresAt: '',
    lastPaymentReference: '',
    updatedAt: new Date().toISOString(),
  };
  await db.tx.add('lc_profiles', [{ id: userId, ...initial }]);
  const [created] = await db.get<Profile>('lc_profiles', [userId], { consistent: true });
  if (!created) throw new Error('Unable to initialize your workspace. Please retry.');
  return created;
}

async function updateProfile(userId: string, patch: Partial<Profile>) {
  const [ok] = await db.tx.update('lc_profiles', [{
    id: userId,
    record: { ...patch, updatedAt: new Date().toISOString() },
  }], { patch: true });
  if (!ok) throw new Error('Could not update your account. Please retry.');
}

async function getUsage(userId: string): Promise<Usage> {
  const [usage] = await db.get<Usage>(usageTable(userId), ['current'], { consistent: true });
  return usage || { month: MONTH(), count: 0 };
}

async function consumeScan(userId: string, limit: number, month = MONTH()): Promise<number> {
  const table = usageTable(userId);
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const [current] = await db.get<Usage>(table, ['current'], { consistent: true });
    if (!current) {
      const [id] = await db.tx.add(table, [{ id: 'current', month, count: 1 }]);
      if (id) return 1;
      continue;
    }
    const count = current.month === month ? current.count : 0;
    if (count >= limit) return -1;
    const [updated] = await db.tx.update(table, [{
      id: 'current',
      record: { month, count: count + 1 },
      if: { month: current.month, count: current.count },
    }], { patch: true });
    if (updated) return count + 1;
  }
  throw new Error('Another scan is being recorded. Please retry in a moment.');
}

async function refundScan(userId: string, reservedMonth: string, reservationId: string) {
  return refundUsageCounter(
    usageTable(userId),
    'lc_scan_refunds_' + safeKey(userId),
    reservationId,
    reservedMonth,
    'scan'
  );
}

type AiErrorPayload = {
  code?: string;
  reached_limits?: string[];
  reset_at?: { daily?: string; monthly?: string };
};

function aiFailureDetails(err: unknown): { status: number; message: string } | null {
  const candidate = (err && typeof err === 'object' ? err : {}) as {
    statusCode?: number;
    responseText?: string;
    message?: string;
  };
  const raw = [
    candidate.message || (err instanceof Error ? err.message : String(err || '')),
    candidate.responseText || '',
  ].join(' ');
  const payloadStart = raw.indexOf('{');
  const payloadEnd = raw.lastIndexOf('}');
  let payload: AiErrorPayload = {};
  if (payloadStart >= 0 && payloadEnd > payloadStart) {
    try {
      payload = JSON.parse(raw.slice(payloadStart, payloadEnd + 1)) as AiErrorPayload;
    } catch {
      payload = {};
    }
  }
  const quota = payload.code === 'ai_usage_limit_exceeded' || /ai usage limit exceeded/i.test(raw);
  const rateLimited = quota
    || Number(candidate.statusCode || 0) === 429
    || (/429/.test(raw) && /ai/i.test(raw));
  if (!rateLimited) return null;

  const resetAt = payload.reset_at?.daily || payload.reset_at?.monthly || '';
  const resetText = resetAt ? ' Try again after ' + resetAt + '.' : ' Please wait briefly and retry.';
  const daily = Boolean(payload.reached_limits?.includes('daily') || payload.reset_at?.daily);
  const message = quota
    ? "ListingCraft's AI analysis quota has been reached" + (daily ? ' for today' : '') + '. Your scan allowance has been restored.' + resetText
    : 'The AI provider is temporarily rate-limiting analysis requests. Your scan allowance has been restored.' + resetText;
  return { status: 429, message };
}

const emailKey = (email: string) => Array.from(new TextEncoder().encode(email.trim().toLowerCase()))
  .map(byte => byte.toString(16).padStart(2, '0')).join('').slice(0, 96);

async function paystackRequest(path: string, method = 'POST', payload?: Record<string, unknown>) {
  const key = await secrets.readSecret('PAYSTACK_SECRET_KEY');
  const response = await fetch('https://api.paystack.co/' + path, {
    method,
    headers: {
      Authorization: 'Bearer ' + key,
      ...(method !== 'GET' ? { 'Content-Type': 'application/json' } : {}),
    },
    ...(method !== 'GET' && payload ? { body: JSON.stringify(payload) } : {}),
  });
  const data = await response.json() as Record<string, any>;
  if (!response.ok || data.status === false) {
    throw new Error(data.message || 'Paystack could not complete the request.');
  }
  return data;
}

function appUrl() {
  return 'https://listingcraft-o1vuq0.v2.appdeploy.ai/';
}

async function ensurePaystackPlan(plan: Exclude<Plan, 'free'>, currency: 'usd' | 'kes') {
  const id = plan + '_' + currency;
  const [saved] = await db.get<{ planCode: string }>('lc_paystack_plans', [id], { consistent: true });
  if (saved?.planCode) return saved.planCode;

  const created = await paystackRequest('plan', 'POST', {
    name: 'ListingCraft ' + PLAN_LABELS[plan] + ' ' + currency.toUpperCase(),
    interval: 'monthly',
    amount: PLAN_PRICES[plan][currency],
    currency: currency.toUpperCase(),
  });
  const planCode = created.data?.plan_code as string | undefined;
  if (!planCode) throw new Error('Paystack did not return a subscription plan code.');
  await db.tx.add('lc_paystack_plans', [{ id, planCode, currency, plan }]);
  const [stored] = await db.get<{ planCode: string }>('lc_paystack_plans', [id], { consistent: true });
  return stored?.planCode || planCode;
}

async function hmacHex(secret: string, value: string) {
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-512' },
    false,
    ['sign']
  );
  const digest = new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value)));
  return Array.from(digest).map(byte => byte.toString(16).padStart(2, '0')).join('');
}

function constantTimeEqual(left: string, right: string) {
  if (left.length !== right.length) return false;
  let mismatch = 0;
  for (let index = 0; index < left.length; index += 1) mismatch |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return mismatch === 0;
}

async function verifyPaystackSignature(rawBody: string, headers: Record<string, string>) {
  const legacy = headers['x-paystack-signature'] || headers['X-Paystack-Signature'];
  if (legacy) {
    try {
      const key = await secrets.readSecret('PAYSTACK_SECRET_KEY');
      return constantTimeEqual(await hmacHex(key, rawBody), legacy);
    } catch {
      return false;
    }
  }

  const signed = headers['paystack-signature'] || headers['Paystack-Signature'];
  if (!signed) return false;
  try {
    const webhookSecret = await secrets.readSecret('PAYSTACK_WEBHOOK_SECRET');
    const parts = signed.split(',').map(part => part.trim().split('='));
    const timestamp = parts.find(part => part[0] === 't')?.[1];
    const signatures = parts.filter(part => part[0] === 'v1').map(part => part[1]?.split(':').pop() || '');
    if (!timestamp || !signatures.length || Math.abs(Date.now() / 1000 - Number(timestamp)) > 300) return false;
    const expected = await hmacHex(webhookSecret, timestamp + '.' + rawBody);
    return signatures.some(candidate => constantTimeEqual(expected, candidate));
  } catch {
    return false;
  }
}

async function userIdForEmail(email: string) {
  if (!email) return '';
  const [mapping] = await db.get<{ userId: string }>('lc_paystack_email_map', [emailKey(email)], { consistent: true });
  return mapping?.userId || '';
}

async function planFromName(name: string): Promise<Plan> {
  const value = (name || '').toLowerCase();
  if (value.includes('agency')) return 'agency';
  if (value.includes('growth')) return 'growth';
  if (value.includes('starter')) return 'starter';
  return 'free';
}

const auditSchema = {
  type: 'object',
  properties: {
    businessName: { type: 'string' },
    score: { type: 'number' },
    summary: { type: 'string' },
    strengths: { type: 'array', items: { type: 'string' } },
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          severity: { type: 'string', enum: ['High', 'Medium', 'Low'] },
          category: { type: 'string' },
          evidence: { type: 'string' },
          recommendation: { type: 'string' },
        },
        required: ['title', 'severity', 'category', 'evidence', 'recommendation'],
      },
    },
  },
  required: ['businessName', 'score', 'summary', 'strengths', 'findings'],
};


const automationTable = (userId: string) => 'lc_automations_' + safeKey(userId);
const automationRunsTable = (userId: string) => 'lc_automation_runs_' + safeKey(userId);
const automationQueueTable = 'lc_automation_queue';
type MonitorCadence = 'daily' | 'weekly';

function nextMonitorRun(cadence: MonitorCadence, from = Date.now()) {
  const interval = cadence === 'weekly' ? 7 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
  return new Date(from + interval).toISOString();
}

async function executeWebsiteMonitor(
  userId: string,
  monitorId: string,
  monitor: Record<string, any>,
  trigger: 'Manual' | 'Scheduled'
) {
  const startedAt = new Date().toISOString();
  let reservationActive = false;
  let reservedMonth = '';
  let reservationId = '';
  try {
    const parsed = validatePublicHttpUrl(String(monitor.website || ''));
    if (!parsed) throw new Error('The saved website URL is no longer valid or publicly reachable.');
    const items = await runApifyActor('apify~website-content-crawler', {
      startUrls: [{ url: parsed.toString() }],
      crawlerType: 'cheerio',
      maxCrawlDepth: 1,
      maxCrawlPages: 3,
      maxResults: 3,
      maxConcurrency: 2,
      respectRobotsTxtFile: true,
      useSitemaps: false,
      proxyConfiguration: { useApifyProxy: true },
      saveHtml: false,
      saveHtmlAsFile: false,
    });
    const pages = items.slice(0, 3).map(item => {
      const metadata = item.metadata && typeof item.metadata === 'object'
        ? item.metadata as Record<string, unknown>
        : {};
      return {
        url: String(item.url || item.loadedUrl || parsed.toString()).slice(0, 1000),
        title: String(item.title || metadata.title || '').slice(0, 240),
        text: String(item.text || item.markdown || item.content || '').slice(0, 9000),
      };
    }).filter(page => page.text.trim().length > 0);
    const pageText = pages.map(page => 'PAGE: ' + page.title + '\nURL: ' + page.url + '\n' + page.text).join('\n\n').slice(0, 24000);
    if (pageText.trim().length < 80) throw new Error('The crawler returned insufficient readable website content. No audit was created.');

    const profile = await getProfile(userId);
    reservedMonth = MONTH();
    reservationId = crypto.randomUUID();
    const used = await consumeScan(userId, PLAN_LIMITS[profile.plan], reservedMonth);
    if (used < 0) throw new Error('The workspace has reached its monthly audit allowance. The monitor will retry at its next scheduled time.');
    reservationActive = true;

    const extracted = await ai.extract({
      prompt: 'You are ListingCraft, a cautious business website auditor. Audit only the supplied public page content. Do not invent facts or claim to have checked Google listings, directories, private systems, actual revenue or legal compliance. Score only the clarity and conversion readiness of this page from 0 to 100. Evidence must refer to supplied text. Return 3 to 6 useful findings when supported. Do not estimate lost revenue.',
      content: 'Business: ' + String(monitor.businessName || parsed.hostname)
        + '\nLocation: ' + String(monitor.location || 'Not supplied')
        + '\nWebsite: ' + parsed.toString()
        + '\nCrawl timestamp: ' + startedAt
        + '\nPUBLIC WEBSITE CONTENT:\n' + pageText,
      schema: auditSchema,
      maxTokens: 1800,
      thinkingMode: 'FAST',
    });
    const data = extracted.data as {
      businessName?: string;
      score?: number;
      summary?: string;
      strengths?: string[];
      findings?: Array<{ title: string; severity: string; category: string; evidence: string; recommendation: string }>;
    };
    if (!data || !Array.isArray(data.findings)) throw new Error('The AI audit returned incomplete structured findings.');
    const report = {
      businessName: String(monitor.businessName || data.businessName || parsed.hostname),
      website: parsed.toString(),
      location: String(monitor.location || 'Not provided'),
      score: Math.max(0, Math.min(100, Math.round(Number(data.score) || 0))),
      summary: String(data.summary || 'Automated review of accessible public website content.'),
      strengths: Array.isArray(data.strengths) ? data.strengths.slice(0, 5).map(String) : [],
      findings: data.findings.slice(0, 6).map(f => ({
        title: String(f.title || 'Review this website signal'),
        severity: (['High', 'Medium', 'Low'].includes(f.severity) ? f.severity : 'Medium') as 'High' | 'Medium' | 'Low',
        category: String(f.category || 'Website'),
        evidence: String(f.evidence || 'Not enough page evidence was available.'),
        recommendation: String(f.recommendation || 'Review this item manually.'),
      })),
      scannedAt: new Date().toISOString(),
      sourceTitle: pages[0]?.title || '',
      sourceActor: 'apify/website-content-crawler',
      sourcePages: pages.length,
      automationId: monitorId,
      userId,
    };
    const [auditId] = await db.add(auditTable(userId), [report]);
    if (!auditId) throw new Error('The audit finished but could not be saved to the workspace.');
    reservationActive = false;
    const run = {
      automationId: monitorId,
      businessName: report.businessName,
      website: report.website,
      trigger,
      status: 'Completed',
      auditId,
      score: report.score,
      findingsCount: report.findings.length,
      summary: report.summary.slice(0, 700),
      startedAt,
      completedAt: new Date().toISOString(),
    };
    const [runId] = await db.add(automationRunsTable(userId), [run]);
    await db.tx.update(automationTable(userId), [{
      id: monitorId,
      record: {
        lastRunAt: run.completedAt,
        lastStatus: 'Completed',
        lastAuditId: auditId,
        lastError: '',
        lastScore: report.score,
        lastFindingsCount: report.findings.length,
      },
    }], { patch: true });
    return { audit: { ...report, id: auditId }, run: { ...run, id: runId }, usage: { count: used, limit: PLAN_LIMITS[profile.plan] } };
  } catch (err) {
    const aiFailure = aiFailureDetails(err);
    const message = aiFailure?.message || (err instanceof Error ? err.message : 'The scheduled website review failed.');
    if (reservationActive) {
      reservationActive = false;
      const refunded = await refundScan(userId, reservedMonth, reservationId);
      if (!refunded) console.error('ListingCraft scheduled scan refund was not confirmed', monitorId);
    }
    const completedAt = new Date().toISOString();
    await db.add(automationRunsTable(userId), [{
      automationId: monitorId,
      businessName: String(monitor.businessName || ''),
      website: String(monitor.website || ''),
      trigger,
      status: 'Failed',
      error: message.slice(0, 700),
      startedAt,
      completedAt,
    }]);
    await db.tx.update(automationTable(userId), [{
      id: monitorId,
      record: { lastRunAt: completedAt, lastStatus: 'Failed', lastError: message.slice(0, 700) },
    }], { patch: true });
    throw new Error(message);
  }
}

export const automationWorker = async (event: {
  type: 'cron';
  name: string;
  invocationId: string;
  payload: Record<string, unknown>;
  scheduledTime: string;
  invokedTime: string;
}) => {
  try {
    const page = await db.list<Record<string, any>>(automationQueueTable, { limit: 100 });
    const now = Date.now();
    const due = page.items
      .filter(item => item.active === true && Date.parse(String(item.nextRunAt || '')) <= now)
      .slice(0, 2);
    for (const queued of due) {
      const [monitor] = await db.get<Record<string, any>>(automationTable(String(queued.userId)), [String(queued.automationId)], { consistent: true });
      if (!monitor || monitor.status !== 'Active') {
        await db.delete(automationQueueTable, [queued.id]);
        continue;
      }
      try {
        await executeWebsiteMonitor(String(queued.userId), String(queued.automationId), monitor, 'Scheduled');
      } catch (err) {
        console.error('ListingCraft scheduled website monitor failed', err);
      }
      const nextRunAt = nextMonitorRun(monitor.cadence === 'weekly' ? 'weekly' : 'daily');
      await db.tx.update(automationQueueTable, [{
        id: queued.id,
        record: { nextRunAt, lastCheckedAt: new Date().toISOString() },
        if: { active: true },
      }], { patch: true });
      await db.tx.update(automationTable(String(queued.userId)), [{
        id: String(queued.automationId),
        record: { nextRunAt },
      }], { patch: true });
    }
  } catch (err) {
    console.error('ListingCraft automation worker could not complete this tick', err);
  }
  return { statusCode: 200 };
};

export const handler = router({
  'GET /api/health': [async () => json({ status: 'ok', product: 'ListingCraft' })],

  'GET /api/me': [
    requireAuth(),
    async ({ user }) => {
      const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
      const usage = await getUsage(user!.userId);
      const currentCount = usage.month === MONTH() ? usage.count : 0;
      return json({
        user: { userId: user!.userId, email: user!.email || '', name: user!.name || '' },
        profile,
        usage: { count: currentCount, limit: PLAN_LIMITS[profile.plan] },
        plans: PLAN_LABELS,
      });
    },
  ],


  'GET /api/automations': [
    requireAuth(),
    async ({ user }) => {
      const page = await db.list<Record<string, any>>(automationTable(user!.userId), { limit: 50 });
      return json({ automations: page.items.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))) });
    },
  ],

  'GET /api/automations/runs': [
    requireAuth(),
    async ({ user }) => {
      const page = await db.list<Record<string, any>>(automationRunsTable(user!.userId), { limit: 50 });
      return json({ runs: page.items.sort((a, b) => String(b.completedAt || '').localeCompare(String(a.completedAt || ''))) });
    },
  ],

  'POST /api/automations': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as {
        businessName?: string;
        website?: string;
        location?: string;
        contactEmail?: string;
        cadence?: string;
        permissionConfirmed?: boolean;
      };
      const businessName = (input.businessName || '').trim().slice(0, 120);
      const location = (input.location || '').trim().slice(0, 160);
      const contactEmail = (input.contactEmail || '').trim().toLowerCase().slice(0, 200);
      const parsed = validatePublicHttpUrl((input.website || '').trim());
      if (!businessName || !location || !parsed) return error('Enter a business name, location and valid public website URL.', 400);
      if (!['daily', 'weekly'].includes(input.cadence || '')) return error('Choose a daily or weekly monitoring schedule.', 400);
      if (input.permissionConfirmed !== true) return error('Confirm that you are authorized to crawl this website and that its published policies permit the review.', 400);
      if (contactEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactEmail)) return error('Enter a valid contact email or leave it blank.', 400);
      const names = await secrets.listSecretNames();
      if (!names.includes('APIFY_API_TOKEN')) return error('Apify is not configured. Add APIFY_API_TOKEN in AppDeploy secure settings.', 503);
      const existing = await db.list<Record<string, any>>(automationTable(user!.userId), { limit: 50 });
      if (existing.items.filter(item => item.status === 'Active').length >= 5) return error('You can have up to five active website monitors in this workspace.', 409);

      const cadence = input.cadence as MonitorCadence;
      const nextRunAt = nextMonitorRun(cadence);
      const monitor = {
        businessName,
        website: parsed.toString(),
        location,
        contactEmail,
        cadence,
        permissionConfirmed: true,
        sourceActor: 'apify/website-content-crawler',
        status: 'Active',
        createdAt: new Date().toISOString(),
        nextRunAt,
        lastRunAt: '',
        lastStatus: 'Not run yet',
        lastAuditId: '',
        lastError: '',
        userId: user!.userId,
      };
      const [id] = await db.add(automationTable(user!.userId), [monitor]);
      if (!id) return error('The monitor could not be saved. Please retry.', 500);
      const [queueId] = await db.add(automationQueueTable, [{
        userId: user!.userId,
        automationId: id,
        active: true,
        cadence,
        nextRunAt,
        createdAt: monitor.createdAt,
      }]);
      if (!queueId) {
        await db.delete(automationTable(user!.userId), [id]);
        return error('The monitor could not be scheduled. No automation was activated.', 500);
      }
      await db.tx.update(automationTable(user!.userId), [{
        id,
        record: { queueId },
      }], { patch: true });
      return json({ automation: { ...monitor, id, queueId }, note: 'The first scheduled run is queued. Use Run now to test immediately. Website reviews consume the workspace monthly audit allowance. Emails are never sent automatically.' }, 201);
    },
  ],

  'POST /api/automations/:id/run': [
    requireAuth(),
    async ({ params, user }) => {
      const [monitor] = await db.get<Record<string, any>>(automationTable(user!.userId), [params.id], { consistent: true });
      if (!monitor) return error('This monitor was not found in your workspace.', 404);
      try {
        const result = await executeWebsiteMonitor(user!.userId, params.id, monitor, 'Manual');
        const nextRunAt = nextMonitorRun(monitor.cadence === 'weekly' ? 'weekly' : 'daily');
        if (monitor.queueId && monitor.status === 'Active') {
          await db.tx.update(automationQueueTable, [{
            id: monitor.queueId,
            record: { nextRunAt, lastCheckedAt: new Date().toISOString() },
            if: { active: true },
          }], { patch: true });
        }
        await db.tx.update(automationTable(user!.userId), [{ id: params.id, record: { nextRunAt } }], { patch: true });
        return json({ ...result, note: 'A real crawl and audit completed. The report is also available in Audit history.' });
      } catch (err) {
        return error(err instanceof Error ? err.message : 'The website monitor could not run.', 502);
      }
    },
  ],

  'POST /api/automations/:id/pause': [
    requireAuth(),
    async ({ params, user }) => {
      const [monitor] = await db.get<Record<string, any>>(automationTable(user!.userId), [params.id], { consistent: true });
      if (!monitor) return error('This monitor was not found in your workspace.', 404);
      await db.tx.update(automationTable(user!.userId), [{ id: params.id, record: { status: 'Paused' } }], { patch: true });
      if (monitor.queueId) {
        await db.tx.update(automationQueueTable, [{ id: monitor.queueId, record: { active: false } }], { patch: true });
      }
      return json({ paused: true });
    },
  ],

  'POST /api/automations/:id/resume': [
    requireAuth(),
    async ({ params, user }) => {
      const [monitor] = await db.get<Record<string, any>>(automationTable(user!.userId), [params.id], { consistent: true });
      if (!monitor) return error('This monitor was not found in your workspace.', 404);
      const nextRunAt = nextMonitorRun(monitor.cadence === 'weekly' ? 'weekly' : 'daily');
      await db.tx.update(automationTable(user!.userId), [{ id: params.id, record: { status: 'Active', nextRunAt } }], { patch: true });
      if (monitor.queueId) {
        await db.tx.update(automationQueueTable, [{ id: monitor.queueId, record: { active: true, nextRunAt } }], { patch: true });
      }
      return json({ resumed: true, nextRunAt });
    },
  ],

  'GET /api/audits': [
    requireAuth(),
    async ({ user }) => {
      const table = auditTable(user!.userId);
      const page = await db.list<Record<string, any>>(table, { limit: 50 });
      return json({ audits: page.items.sort((a, b) => String(b.scannedAt).localeCompare(String(a.scannedAt))) });
    },
  ],

  'POST /api/audit': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as { url?: string; businessName?: string; location?: string };
      if (!input.url || typeof input.url !== 'string') return error('A public website URL is required.', 400);
      let parsed: URL;
      try {
        parsed = new URL(input.url);
        if (!['http:', 'https:'].includes(parsed.protocol)) return error('Only HTTP and HTTPS websites are supported.', 400);
        if (parsed.username || parsed.password) return error('URLs containing credentials are not supported.', 400);
        const hostname = parsed.hostname.toLowerCase();
        if (hostname === 'localhost' || hostname.endsWith('.localhost') || hostname === '127.0.0.1' || hostname === '::1' || hostname.startsWith('10.') || hostname.startsWith('192.168.') || hostname.startsWith('169.254.')) {
          return error('Private and local network addresses cannot be scanned.', 400);
        }
      } catch {
        return error('Please provide a valid public website URL.', 400);
      }
      const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
      const reservedMonth = MONTH();
      const reservationId = crypto.randomUUID();
      const used = await consumeScan(user!.userId, PLAN_LIMITS[profile.plan], reservedMonth);
      if (used < 0) return error('You have reached your monthly audit allowance. Upgrade your plan to continue.', 402);
      let reservationActive = true;
      let failureStatus = 502;
      let failureMessage = 'The website could not be analyzed right now. Please retry in a moment.';
      try {
        const scraped = await ai.scrape({ url: parsed.toString() });
        if (scraped.status === 429) {
          failureStatus = 429;
          failureMessage = 'AI analysis is temporarily rate-limited. Your scan allowance will be restored. Please wait briefly and retry.';
          throw new Error('AI provider rate limit (429)');
        }
        if (scraped.status >= 400 || !scraped.text || scraped.text.trim().length < 80) {
          failureStatus = 422;
          failureMessage = 'We could not retrieve enough public page content. Check the URL or try another public page.';
          throw new Error(failureMessage);
        }
        const extracted = await ai.extract({
          prompt: 'You are ListingCraft, a cautious business website auditor. Audit only the supplied public page content. Do not invent facts or claim to have checked Google listings, directories, private systems, actual revenue or legal compliance. Score only the clarity and conversion readiness of this page from 0 to 100. Evidence must refer to supplied text. Return 3 to 6 useful findings when supported. Do not estimate lost revenue.',
          content: 'Business: ' + (input.businessName || 'Not supplied') + '\nLocation: ' + (input.location || 'Not supplied') + '\nPage title: ' + (scraped.title || 'Unknown') + '\nURL: ' + parsed.toString() + '\nPUBLIC PAGE CONTENT:\n' + scraped.text.slice(0, 24000),
          schema: auditSchema,
          maxTokens: 1800,
          thinkingMode: 'FAST',
        });
        const data = extracted.data as {
          businessName?: string;
          score?: number;
          summary?: string;
          strengths?: string[];
          findings?: Array<{ title: string; severity: string; category: string; evidence: string; recommendation: string }>;
        };
        if (!data || !Array.isArray(data.findings)) {
          failureStatus = 502;
          failureMessage = 'The AI audit returned an incomplete report. Please try again.';
          throw new Error(failureMessage);
        }
        const findings = data.findings.slice(0, 6).map(f => ({
          title: String(f.title || 'Review this website signal'),
          severity: (['High', 'Medium', 'Low'].includes(f.severity) ? f.severity : 'Medium') as 'High' | 'Medium' | 'Low',
          category: String(f.category || 'Website'),
          evidence: String(f.evidence || 'Not enough page evidence was available.'),
          recommendation: String(f.recommendation || 'Review this item manually.'),
        }));
        const report = {
          businessName: input.businessName?.trim() || data.businessName || scraped.title || parsed.hostname,
          website: parsed.toString(),
          location: input.location?.trim() || 'Not provided',
          score: Math.max(0, Math.min(100, Math.round(Number(data.score) || 0))),
          summary: String(data.summary || 'Automated review of accessible public website content.'),
          strengths: Array.isArray(data.strengths) ? data.strengths.slice(0, 5).map(String) : [],
          findings,
          scannedAt: new Date().toISOString(),
          sourceTitle: scraped.title || '',
        };
        failureStatus = 500;
        failureMessage = 'The audit was completed but could not be saved. Please retry.';
        const [id] = await db.add(auditTable(user!.userId), [{ ...report, userId: user!.userId }]);
        if (!id) throw new Error(failureMessage);
        reservationActive = false;
        return json({ audit: { ...report, id }, usage: { count: used, limit: PLAN_LIMITS[profile.plan] } });
      } catch (err) {
        const aiFailure = aiFailureDetails(err);
        const message = aiFailure?.message || failureMessage;
        const status = aiFailure?.status || failureStatus;
        if (reservationActive) {
          reservationActive = false;
          const refunded = await refundScan(user!.userId, reservedMonth, reservationId);
          if (!refunded) console.error('ListingCraft manual scan refund was not confirmed', user!.userId);
        }
        console.error('ListingCraft audit failed', { status, message });
        return error(message, status);
      }
    },
  ],

  'GET /api/prospects': [
    requireAuth(),
    async ({ user }) => {
      const page = await db.list<Record<string, any>>(prospectTable(user!.userId), { limit: 100 });
      return json({ prospects: page.items.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))) });
    },
  ],

  'POST /api/prospects': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as { businessName?: string; website?: string; contactEmail?: string; notes?: string; status?: string };
      if (!input.businessName?.trim()) return error('A business name is required.', 400);
      if (input.website && !/^https?:\/\//i.test(input.website)) return error('Use a valid public website URL.', 400);
      const prospect = {
        businessName: input.businessName.trim().slice(0, 120),
        website: (input.website || '').trim().slice(0, 300),
        contactEmail: (input.contactEmail || '').trim().slice(0, 200),
        notes: (input.notes || '').trim().slice(0, 1200),
        status: ['New', 'Contacted', 'Qualified', 'Won', 'Lost'].includes(input.status || '') ? input.status : 'New',
        createdAt: new Date().toISOString(),
      };
      const [id] = await db.add(prospectTable(user!.userId), [{ ...prospect, userId: user!.userId }]);
      if (!id) return error('Could not save this prospect.', 500);
      return json({ prospect: { ...prospect, id } }, 201);
    },
  ],


  'GET /api/integrations/status': [
    requireAuth(),
    async () => {
      const names = await secrets.listSecretNames();
      return json({
        apifyConfigured: names.includes('APIFY_API_TOKEN'),
        businessDiscovery: {
          actor: 'compass/crawler-google-places',
          enabled: GOOGLE_PLACES_COMMERCIAL_USE_ENABLED,
          maxBusinessesPerRun: BUSINESS_DISCOVERY_LIMIT,
          status: GOOGLE_PLACES_COMMERCIAL_USE_ENABLED ? 'enabled' : 'blocked_pending_commercial_source_review',
        },
        websiteCrawler: {
          actor: 'apify/website-content-crawler',
          enabled: names.includes('APIFY_API_TOKEN'),
          maxPagesPerRun: 3,
          respectsRobotsTxt: true,
        },
        googleSearchDiscovery: {
          actor: 'apify/google-search-scraper',
          configured: names.includes('APIFY_API_TOKEN'),
          enabled: names.includes('APIFY_API_TOKEN'),
          maxBusinessesPerRun: BUSINESS_DISCOVERY_LIMIT,
          liveTested: false,
        },
        contactDetailsEnrichment: {
          actor: 'data_wiki/contact-details-scraper',
          configured: names.includes('APIFY_API_TOKEN'),
          enabled: names.includes('APIFY_API_TOKEN'),
          maxWebsitesPerRun: 10,
          liveTested: false,
        },
        propertyDiscovery: {
          actor: 'maxcopell/zillow-scraper',
          enabled: ZILLOW_COMMERCIAL_USE_ENABLED,
          status: ZILLOW_COMMERCIAL_USE_ENABLED ? 'enabled' : 'blocked_pending_commercial_source_review',
        },
      });
    },
  ],

  'GET /api/discovery/usage': [
    requireAuth(),
    async ({ user }) => {
      const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
      const usage = await getDiscoveryUsage(user!.userId);
      return json({
        count: usage.month === MONTH() ? usage.count : 0,
        limit: PLAN_LIMITS[profile.plan],
        month: MONTH(),
        maxBusinessesPerRun: BUSINESS_DISCOVERY_LIMIT,
      });
    },
  ],

  'POST /api/discovery/businesses': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as {
        industry?: string;
        location?: string;
        sourcePermissionConfirmed?: boolean;
      };
      if (!input.industry?.trim() || !input.location?.trim()) {
        return error('Enter an industry and a city or country.', 400);
      }
      if (input.sourcePermissionConfirmed !== true) {
        return error('Confirm that you have reviewed and are authorized to use this data source before running discovery.', 400);
      }
      if (!GOOGLE_PLACES_COMMERCIAL_USE_ENABLED) {
        return error('Google Maps discovery is configured but remains disabled until written commercial-use and source-terms clearance is recorded. Apify access alone does not grant Google data rights.', 403);
      }
      const names = await secrets.listSecretNames();
      if (!names.includes('APIFY_API_TOKEN')) return error('Apify is not configured for this workspace.', 503);
      const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
      const reservedMonth = MONTH();
      const reservationId = crypto.randomUUID();
      const used = await consumeDiscoveryRun(user!.userId, PLAN_LIMITS[profile.plan], reservedMonth);
      if (used < 0) return error('You have reached this month’s discovery-run allowance.', 402);
      let reservationActive = true;
      try {
        const items = await runApifyActor('compass~crawler-google-places', {
          searchStringsArray: [input.industry.trim().slice(0, 100) + ' in ' + input.location.trim().slice(0, 120)],
          maxCrawledPlacesPerSearch: BUSINESS_DISCOVERY_LIMIT,
          language: 'en',
          maxReviews: 0,
        });
        const now = new Date().toISOString();
        const normalized = items.slice(0, BUSINESS_DISCOVERY_LIMIT).map(item => {
          const title = String(item.title || item.name || item.businessName || '').trim();
          const website = String(item.website || '').trim();
          const mapUrl = String(item.url || item.googleMapsUrl || '').trim();
          const address = String(item.address || item.street || input.location || '').trim();
          const category = String(item.categoryName || item.category || input.industry || '').trim();
          const details = [
            'Source: compass/crawler-google-places via Apify',
            'Collected: ' + now,
            item.phone ? 'Public business phone: ' + String(item.phone) : '',
            item.totalScore ? 'Source rating: ' + String(item.totalScore) : '',
            item.reviewsCount ? 'Source review count: ' + String(item.reviewsCount) : '',
            mapUrl ? 'Map source: ' + mapUrl : '',
          ].filter(Boolean).join('\n');
          return { title, website, mapUrl, address, category, details };
        }).filter(item => item.title);
        if (!normalized.length) return error('The actor completed but returned no usable business records. No leads were fabricated or saved.', 422);
        const records = normalized.map(item => ({
          kind: 'business',
          title: item.title.slice(0, 180),
          location: item.address.slice(0, 160) || input.location!.trim().slice(0, 160),
          industry: item.category.slice(0, 120),
          sourceUrl: (item.website || item.mapUrl).slice(0, 500),
          details: item.details.slice(0, 1800),
          sourceProvider: 'compass/crawler-google-places',
          status: 'Needs review',
          createdAt: now,
          userId: user!.userId,
        }));
        const ids = await db.add(opportunityTable(user!.userId), records);
        const saved = records.flatMap((record, index) => ids[index] ? [{ ...record, id: ids[index] }] : []);
        if (!saved.length) return error('The actor returned business records, but none could be saved. No discovery allowance was consumed.', 500);
        reservationActive = false;
        return json({ results: saved, count: saved.length, usage: { count: used, limit: PLAN_LIMITS[profile.plan] } });
      } catch (err) {
        console.error('ListingCraft business discovery failed', err);
        return error('The business discovery actor did not complete successfully. No simulated results were returned.', 502);
      } finally {
        if (reservationActive) {
          reservationActive = false;
          await refundDiscoveryRun(user!.userId, reservedMonth, reservationId);
        }
      }
    },
  ],

  'POST /api/discovery/search': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as {
        industry?: string;
        location?: string;
        countryCode?: string;
        sourcePermissionConfirmed?: boolean;
      };
      const industry = (input.industry || '').trim().slice(0, 100);
      const location = (input.location || '').trim().slice(0, 120);
      const countryCode = (input.countryCode || 'ke').trim().toLowerCase();
      if (!industry || !location) return error('Enter an industry and a city or country.', 400);
      if (!/^[a-z]{2}$/.test(countryCode)) return error('Choose a valid two-letter search country code.', 400);
      if (input.sourcePermissionConfirmed !== true) {
        return error('Review the Google Search actor terms and applicable data rules, then confirm that this search is appropriate for your intended use.', 400);
      }
      const names = await secrets.listSecretNames();
      if (!names.includes('APIFY_API_TOKEN')) return error('Apify is not configured for this workspace.', 503);

      const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
      const reservedMonth = MONTH();
      const reservationId = crypto.randomUUID();
      const used = await consumeDiscoveryRun(user!.userId, PLAN_LIMITS[profile.plan], reservedMonth);
      if (used < 0) return error('You have reached this month’s discovery-run allowance.', 402);
      let reservationActive = true;
      try {
        const query = industry + ' businesses in ' + location;
        const pages = await runApifyActor('apify~google-search-scraper', {
          queries: [query],
          countryCode,
          languageCode: 'en',
          maxPagesPerQuery: 5,
          includePeopleAlsoAsk: false,
          includeRelatedSearches: false,
          maxConcurrency: 2,
        });
        const candidates: Array<Record<string, unknown>> = pages.flatMap(page => {
          const nested = Array.isArray(page.organicResults) ? page.organicResults
            : Array.isArray(page.results) ? page.results : null;
          return (nested || [page]) as Array<Record<string, unknown>>;
        });
        const seenDomains = new Set<string>();
        const now = new Date().toISOString();
        const records = candidates
          .filter(item => !item.type || String(item.type).toLowerCase() === 'organic')
          .map(item => {
            const title = String(item.title || item.name || '').trim();
            const rawUrl = String(item.url || item.link || '').trim();
            const parsed = validatePublicHttpUrl(rawUrl);
            if (!title || !parsed || parsed.hostname.toLowerCase().includes('google.')) return null;
            const hostname = parsed.hostname.toLowerCase();
            const domain = hostname.startsWith('www.') ? hostname.slice(4) : hostname;
            if (seenDomains.has(domain)) return null;
            seenDomains.add(domain);
            const description = String(item.description || item.snippet || '').trim();
            return {
              kind: 'business',
              title: title.slice(0, 180),
              location: location.slice(0, 160),
              industry: industry.slice(0, 120),
              sourceUrl: parsed.toString().slice(0, 500),
              details: [
                'Source: apify/google-search-scraper',
                'Search query: ' + query,
                'Collected: ' + now,
                description ? 'Search snippet: ' + description : '',
              ].filter(Boolean).join(String.fromCharCode(10)).slice(0, 1800),
              sourceProvider: 'apify/google-search-scraper',
              status: 'Needs review',
              createdAt: now,
              userId: user!.userId,
            };
          })
          .filter((item): item is NonNullable<typeof item> => Boolean(item))
          .slice(0, BUSINESS_DISCOVERY_LIMIT);
        if (!records.length) return error('Google Search completed but returned no usable organic business websites. No leads were fabricated or saved.', 422);
        const ids = await db.add(opportunityTable(user!.userId), records);
        const saved = records.flatMap((record, index) => ids[index] ? [{ ...record, id: ids[index] }] : []);
        if (!saved.length) return error('Search results were returned but could not be saved. No discovery allowance was consumed.', 500);
        reservationActive = false;
        return json({
          results: saved,
          count: saved.length,
          maxBusinessesPerRun: BUSINESS_DISCOVERY_LIMIT,
          usage: { count: used, limit: PLAN_LIMITS[profile.plan] },
          source: 'apify/google-search-scraper',
        });
      } catch (err) {
        console.error('ListingCraft Google Search discovery failed', err);
        return error('The Google Search actor did not complete successfully. No simulated results were returned.', 502);
      } finally {
        if (reservationActive) {
          reservationActive = false;
          await refundDiscoveryRun(user!.userId, reservedMonth, reservationId);
        }
      }
    },
  ],

  'POST /api/enrichment/contacts': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as {
        urls?: string[];
        countryCode?: string;
        permissionConfirmed?: boolean;
      };
      if (!Array.isArray(input.urls) || input.urls.length === 0) {
        return error('Add at least one public business website URL.', 400);
      }
      const uniqueUrls = Array.from(new Set(input.urls.map(value => String(value).trim()).filter(Boolean))).slice(0, 50);
      if (!uniqueUrls.length) return error('Add at least one valid public business website URL.', 400);
      const parsedUrls = uniqueUrls.map(value => validatePublicHttpUrl(value));
      if (parsedUrls.some(value => !value)) {
        return error('Every entry must be a valid public HTTP or HTTPS website. Local and private-network targets are blocked.', 400);
      }
      if (input.permissionConfirmed !== true) {
        return error('Confirm that you have reviewed the websites’ published access policies and are authorized to collect their public business contact details.', 400);
      }
      const countryCode = (input.countryCode || 'KE').trim().toUpperCase();
      if (!/^[A-Z]{2}$/.test(countryCode)) return error('Choose a valid two-letter phone country code.', 400);
      const names = await secrets.listSecretNames();
      if (!names.includes('APIFY_API_TOKEN')) return error('Apify is not configured for this workspace.', 503);

      // The Actor's published free tier currently limits a run to ten website results.
      // Keep each run within that limit; the 50-prospect discovery cap remains unchanged.
      const runUrls = parsedUrls.slice(0, 10).map(value => (value as URL).toString());
      const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
      const reservedMonth = MONTH();
      const reservationId = crypto.randomUUID();
      const used = await consumeDiscoveryRun(user!.userId, PLAN_LIMITS[profile.plan], reservedMonth);
      if (used < 0) return error('You have reached this month’s discovery and enrichment run allowance.', 402);
      let reservationActive = true;
      try {
        const items = await runApifyActor('data_wiki~contact-details-scraper', {
          urls: runUrls,
          maxWebsites: runUrls.length,
          maxPagesPerSite: 5,
          verifyEmails: true,
          country: countryCode,
          onlyWithContacts: false,
        });
        const now = new Date().toISOString();
        const records = items.map(item => {
          const company = item.company && typeof item.company === 'object'
            ? item.company as Record<string, unknown> : {};
          const rawWebsite = String(item.originalStartUrl || item.url
            || (item.domain ? 'https://' + String(item.domain) : '')).trim();
          const website = validatePublicHttpUrl(rawWebsite);
          if (!website) return null;
          const emails = Array.isArray(item.emails)
            ? item.emails.map(value => String(value).trim()).filter(value => {
              const at = value.indexOf('@');
              return at > 0 && value.indexOf('.', at) > at + 1 && !value.includes(' ');
            })
            : [];
          const phones = Array.isArray(item.phones) ? item.phones.map(String).slice(0, 5) : [];
          const socialFields = ['linkedIns', 'twitters', 'instagrams', 'facebooks', 'youtubes', 'tiktoks', 'whatsapps'];
          const socials = socialFields.flatMap(field => Array.isArray(item[field])
            ? (item[field] as unknown[]).map(String).slice(0, 2) : []).slice(0, 8);
          const businessName = String(company.name || item.companyName || item.name || website.hostname).trim().slice(0, 120);
          const notes = [
            'Source: data_wiki/contact-details-scraper via Apify',
            'Collected: ' + now,
            'Actor status: ' + String(item.status || 'returned'),
            phones.length ? 'Public phone numbers: ' + phones.join(', ') : '',
            socials.length ? 'Public social profiles: ' + socials.join(', ') : '',
            typeof item.contactConfidence === 'number' ? 'Contact confidence: ' + item.contactConfidence + '/100' : '',
          ].filter(Boolean).join(String.fromCharCode(10)).slice(0, 1200);
          return {
            businessName,
            website: website.toString().slice(0, 300),
            contactEmail: emails[0] || '',
            notes,
            status: 'New',
            sourceProvider: 'data_wiki/contact-details-scraper',
            collectedAt: now,
            userId: user!.userId,
          };
        }).filter((item): item is NonNullable<typeof item> => Boolean(item));
        if (!records.length) return error('The contact-details actor returned no usable website records. No placeholder contacts were created.', 422);
        const ids = await db.add(prospectTable(user!.userId), records);
        const saved = records.flatMap((record, index) => ids[index] ? [{ ...record, id: ids[index] }] : []);
        if (!saved.length) return error('Contact results could not be saved. No discovery allowance was consumed.', 500);
        reservationActive = false;
        return json({
          prospects: saved,
          count: saved.length,
          requested: runUrls.length,
          note: 'One contact-enrichment run processes up to ten websites on the Actor’s published free tier. Additional websites can be submitted in another run.',
          usage: { count: used, limit: PLAN_LIMITS[profile.plan] },
        });
      } catch (err) {
        console.error('ListingCraft contact enrichment failed', err);
        return error('The contact-details actor did not complete successfully. No placeholder contacts were created.', 502);
      } finally {
        if (reservationActive) {
          reservationActive = false;
          await refundDiscoveryRun(user!.userId, reservedMonth, reservationId);
        }
      }
    },
  ],

  'POST /api/enrichment/website': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as { url?: string; permissionConfirmed?: boolean };
      if (!input.url?.trim()) return error('Enter a business website URL.', 400);
      const parsed = validatePublicHttpUrl(input.url.trim());
      if (!parsed) return error('Enter a valid public HTTP or HTTPS website. Local and private-network targets are blocked.', 400);
      if (input.permissionConfirmed !== true) {
        return error('Confirm that you are authorized to crawl this website and that the crawl is appropriate for its published policies.', 400);
      }
      const names = await secrets.listSecretNames();
      if (!names.includes('APIFY_API_TOKEN')) return error('Apify is not configured for this workspace.', 503);
      const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
      const reservedMonth = MONTH();
      const reservationId = crypto.randomUUID();
      const used = await consumeDiscoveryRun(user!.userId, PLAN_LIMITS[profile.plan], reservedMonth);
      if (used < 0) return error('You have reached this month’s discovery and enrichment run allowance.', 402);
      let reservationActive = true;
      try {
        const items = await runApifyActor('apify~website-content-crawler', {
          startUrls: [{ url: parsed.toString() }],
          crawlerType: 'cheerio',
          maxCrawlDepth: 1,
          maxCrawlPages: 3,
          maxResults: 3,
          maxConcurrency: 2,
          respectRobotsTxtFile: true,
          useSitemaps: false,
          proxyConfiguration: { useApifyProxy: true },
          saveHtml: false,
          saveHtmlAsFile: false,
        });
        const pages = items.slice(0, 3).map(item => {
          const metadata = item.metadata && typeof item.metadata === 'object'
            ? item.metadata as Record<string, unknown>
            : {};
          return {
            url: String(item.url || item.loadedUrl || parsed.toString()).slice(0, 1000),
            title: String(item.title || metadata.title || '').slice(0, 240),
            text: String(item.text || item.markdown || item.content || '').slice(0, 12000),
          };
        }).filter(page => page.text.trim().length > 0);
        if (!pages.length) return error('The crawler completed but returned no readable page content. Check the site permissions and try again.', 422);
        const crawl = {
          url: parsed.toString(),
          sourceActor: 'apify/website-content-crawler',
          collectedAt: new Date().toISOString(),
          respectsRobotsTxt: true,
          pages,
          userId: user!.userId,
        };
        const [id] = await db.add('lc_site_crawls_' + safeKey(user!.userId), [crawl]);
        if (!id) return error('The crawl completed but could not be saved to your workspace. No discovery allowance was consumed.', 500);
        reservationActive = false;
        return json({
          crawl: { ...crawl, id },
          usage: { count: used, limit: PLAN_LIMITS[profile.plan] },
        });
      } catch (err) {
        console.error('ListingCraft website enrichment failed', err);
        return error('The website crawler did not complete successfully. No simulated content was returned.', 502);
      } finally {
        if (reservationActive) {
          reservationActive = false;
          await refundDiscoveryRun(user!.userId, reservedMonth, reservationId);
        }
      }
    },
  ],

  'POST /api/discovery/zillow': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as { searchUrl?: string; sourcePermissionConfirmed?: boolean };
      if (!input.searchUrl?.trim()) return error('Provide a Zillow search URL.', 400);
      let parsed: URL;
      try {
        parsed = new URL(input.searchUrl.trim());
        if (parsed.hostname !== 'www.zillow.com' && parsed.hostname !== 'zillow.com') throw new Error('host');
        if (!parsed.searchParams.has('searchQueryState')) throw new Error('query');
      } catch {
        return error('Provide a valid Zillow search URL containing searchQueryState.', 400);
      }
      if (input.sourcePermissionConfirmed !== true) return error('Confirm that you have reviewed and are authorized to use this Zillow data source.', 400);
      if (!ZILLOW_COMMERCIAL_USE_ENABLED) {
        return error('The Zillow actor is retained in configuration but disabled until its terms, licensing and multi-customer commercial-use rights are cleared.', 403);
      }
      const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
      const reservedMonth = MONTH();
      const reservationId = crypto.randomUUID();
      const used = await consumeDiscoveryRun(user!.userId, PLAN_LIMITS[profile.plan], reservedMonth);
      if (used < 0) return error('You have reached this month’s discovery-run allowance.', 402);
      let reservationActive = true;
      try {
        const items = await runApifyActor('maxcopell~zillow-scraper', {
          searchUrls: [{ url: parsed.toString() }],
          extractionMethod: 'PAGINATION_WITH_ZOOM_IN',
          resultsLimit: BUSINESS_DISCOVERY_LIMIT,
        });
        if (!items.length) return error('The Zillow actor returned no usable property records. No discovery allowance was consumed.', 422);
        reservationActive = false;
        return json({
          results: items.slice(0, BUSINESS_DISCOVERY_LIMIT),
          count: Math.min(items.length, BUSINESS_DISCOVERY_LIMIT),
          source: 'maxcopell/zillow-scraper',
          note: 'Property records require human review and permitted-use verification before reuse.',
          usage: { count: used, limit: PLAN_LIMITS[profile.plan] },
        });
      } catch (err) {
        console.error('ListingCraft Zillow actor failed', err);
        return error('The Zillow actor did not complete successfully. No simulated property records were returned.', 502);
      } finally {
        if (reservationActive) {
          reservationActive = false;
          await refundDiscoveryRun(user!.userId, reservedMonth, reservationId);
        }
      }
    },
  ],

  'GET /api/proposals': [
    requireAuth(),
    async ({ user }) => {
      const page = await db.list<Record<string, any>>(proposalTable(user!.userId), { limit: 50 });
      return json({
        proposals: page.items.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))),
      });
    },
  ],

  'POST /api/proposals/generate': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as {
        auditId?: string;
        recipientEmail?: string;
        offerDescription?: string;
      };
      const auditId = (input.auditId || '').trim();
      const recipientEmail = (input.recipientEmail || '').trim().toLowerCase();
      const offerDescription = (input.offerDescription || '').trim().slice(0, 1200);

      if (!auditId) return error('Choose a saved website audit first.', 400);
      if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(recipientEmail)) {
        return error('Enter a valid recipient email address.', 400);
      }

      const [audit] = await db.get<Record<string, any>>(auditTable(user!.userId), [auditId], { consistent: true });
      if (!audit) return error('That audit was not found in your private workspace.', 404);

      const evidence = {
        businessName: audit.businessName,
        website: audit.website,
        location: audit.location,
        score: audit.score,
        summary: audit.summary,
        findings: audit.findings,
        strengths: audit.strengths,
        scannedAt: audit.scannedAt,
      };

      try {
        const generated = await ai.extract({
          prompt: 'Create a concise, professional first-contact proposal email for a business improvement service. Use only the supplied audit evidence and the user-supplied service description. Do not invent facts, prices, revenue losses, ROI, performance measurements, customer names, deadlines, or guarantees. Do not claim that any service has already been performed. Clearly describe the audit as a review of accessible public website content. Make the subject specific to the business. Keep the tone helpful, respectful, and non-alarmist. Return the subject, email body, executive summary, and proposed solution.',
          content: JSON.stringify({
            auditEvidence: evidence,
            recipientEmail,
            serviceOffered: offerDescription || 'A tailored website improvement and digital presence service. Do not invent specific deliverables beyond the audit evidence.',
          }),
          schema: {
            type: 'object',
            properties: {
              subject: { type: 'string' },
              emailBody: { type: 'string' },
              executiveSummary: { type: 'string' },
              proposedSolution: { type: 'string' },
            },
            required: ['subject', 'emailBody', 'executiveSummary', 'proposedSolution'],
          },
          maxTokens: 1600,
          thinkingMode: 'FAST',
        });

        const data = generated.data as {
          subject?: string;
          emailBody?: string;
          executiveSummary?: string;
          proposedSolution?: string;
        };
        if (!data || !data.subject?.trim() || !data.emailBody?.trim()
          || !data.executiveSummary?.trim() || !data.proposedSolution?.trim()) {
          return error('The proposal generator returned an incomplete draft. Please try again.', 502);
        }

        const proposal = {
          sourceAuditId: auditId,
          businessName: String(audit.businessName || audit.website || 'Business'),
          website: String(audit.website || ''),
          recipientEmail,
          subject: data.subject.trim().slice(0, 240),
          emailBody: data.emailBody.trim().slice(0, 12000),
          executiveSummary: data.executiveSummary.trim().slice(0, 1200),
          proposedSolution: data.proposedSolution.trim().slice(0, 2400),
          status: 'Draft',
          createdAt: new Date().toISOString(),
          userId: user!.userId,
        };
        const [id] = await db.add(proposalTable(user!.userId), [proposal]);
        if (!id) return error('The proposal was generated but could not be saved. Please retry.', 500);
        return json({ proposal: { ...proposal, id } }, 201);
      } catch (err) {
        console.error('ListingCraft proposal generation failed', err);
        return error('The proposal could not be generated right now. No placeholder draft was saved.', 502);
      }
    },
  ],

  'GET /api/email/status': [
    requireAuth(),
    async () => {
      const names = await secrets.listSecretNames();
      const required = [
        'SENDGRID_API_KEY',
        'OUTREACH_FROM_EMAIL',
        'OUTREACH_FROM_NAME',
        'OUTREACH_REPLY_TO',
        'OUTREACH_POSTAL_ADDRESS',
      ];
      const missing = required.filter(name => !names.includes(name));
      let fromEmail = '';
      let fromName = '';
      if (!missing.includes('OUTREACH_FROM_EMAIL')) fromEmail = await secrets.readSecret('OUTREACH_FROM_EMAIL');
      if (!missing.includes('OUTREACH_FROM_NAME')) fromName = await secrets.readSecret('OUTREACH_FROM_NAME');
      return json({
        configured: missing.length === 0,
        missing,
        fromEmail,
        fromName,
        dailyLimit: 10,
        note: 'Configuration presence only. SendGrid verifies the sender identity and API permission when a message is submitted.',
      });
    },
  ],

  'POST /api/email/suppress': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as { email?: string };
      const email = (input.email || '').trim().toLowerCase();
      if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) return error('Enter a valid email address.', 400);
      const table = emailSuppressionTable(user!.userId);
      const id = emailKey(email);
      const [existing] = await db.get<Record<string, any>>(table, [id], { consistent: true });
      if (existing) return json({ suppressed: true, email });
      const [saved] = await db.tx.add(table, [{
        id,
        email,
        reason: 'recipient_opt_out',
        createdAt: new Date().toISOString(),
      }]);
      if (!saved) return error('Could not save the opt-out. Please retry.', 500);
      return json({ suppressed: true, email }, 201);
    },
  ],

  'POST /api/proposals/send': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as { proposalId?: string; confirmRecipientPermission?: boolean };
      const proposalId = (input.proposalId || '').trim();
      if (!proposalId) return error('Choose a saved proposal draft.', 400);
      if (input.confirmRecipientPermission !== true) {
        return error('Confirm that this is relevant, lawful business outreach and the recipient has not opted out.', 400);
      }

      const table = proposalTable(user!.userId);
      const [proposal] = await db.get<Record<string, any>>(table, [proposalId], { consistent: true });
      if (!proposal) return error('That proposal was not found in your private workspace.', 404);
      if (proposal.status === 'Accepted' || proposal.status === 'Sent') {
        return error('This proposal has already been accepted by the email provider. Do not send it again.', 409);
      }
      if (proposal.status === 'Sending') return error('This proposal is already being submitted. Check its status before retrying.', 409);
      if (!proposal.recipientEmail || !proposal.subject || !proposal.emailBody) {
        return error('The proposal is missing its recipient, subject or body.', 422);
      }

      const suppressionId = emailKey(String(proposal.recipientEmail));
      const [suppressed] = await db.get<Record<string, any>>(
        emailSuppressionTable(user!.userId),
        [suppressionId],
        { consistent: true }
      );
      if (suppressed) return error('This recipient is on your workspace opt-out list. Sending is blocked.', 409);

      const names = await secrets.listSecretNames();
      const required = [
        'SENDGRID_API_KEY',
        'OUTREACH_FROM_EMAIL',
        'OUTREACH_FROM_NAME',
        'OUTREACH_REPLY_TO',
        'OUTREACH_POSTAL_ADDRESS',
      ];
      const missing = required.filter(name => !names.includes(name));
      if (missing.length) return error('Email setup is incomplete. Add the sender details in AppDeploy secure settings before sending.', 503);

      const [apiKey, fromEmail, fromName, replyTo, postalAddress] = await Promise.all([
        secrets.readSecret('SENDGRID_API_KEY'),
        secrets.readSecret('OUTREACH_FROM_EMAIL'),
        secrets.readSecret('OUTREACH_FROM_NAME'),
        secrets.readSecret('OUTREACH_REPLY_TO'),
        secrets.readSecret('OUTREACH_POSTAL_ADDRESS'),
      ]);
      const validEmail = (value: string) => /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(value);
      if (!validEmail(fromEmail) || !validEmail(replyTo) || !fromName.trim() || !postalAddress.trim()) {
        return error('Sender configuration is invalid. Check the sender email, reply-to email, business name and postal address.', 422);
      }

      const [locked] = await db.tx.update(table, [{
        id: proposalId,
        record: { status: 'Sending', sendStartedAt: new Date().toISOString() },
        if: { status: proposal.status },
      }], { patch: true });
      if (!locked) return error('This proposal changed while you were preparing to send it. Refresh and try again.', 409);

      try {
        const used = await consumeEmailSend(user!.userId, 10);
        if (used < 0) {
          await db.tx.update(table, [{ id: proposalId, record: { status: proposal.status }, if: { status: 'Sending' } }], { patch: true });
          return error('You have reached the initial limit of 10 proposal emails per day. Try again tomorrow.', 429);
        }

        const optOutAddress = 'mailto:' + replyTo + '?subject=' + encodeURIComponent('Unsubscribe');
        const footer = '\\n\\n' + fromName + '\\n' + postalAddress
          + '\\n\\nTo stop receiving further business emails, reply to this message with the word UNSUBSCRIBE.';
        const textBody = String(proposal.emailBody) + footer;
        const htmlBody = '<div style="font-family:Arial,sans-serif;white-space:pre-wrap;line-height:1.6">'
          + escapeEmailHtml(String(proposal.emailBody))
          + '</div><hr><p style="font-family:Arial,sans-serif;font-size:12px;color:#666">'
          + escapeEmailHtml(fromName) + '<br>' + escapeEmailHtml(postalAddress)
          + '<br>To stop receiving further business emails, <a href="' + escapeEmailHtml(optOutAddress)
          + '">reply to this email with UNSUBSCRIBE</a>.</p>';

        const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
          method: 'POST',
          headers: {
            Authorization: 'Bearer ' + apiKey,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            personalizations: [{ to: [{ email: String(proposal.recipientEmail) }] }],
            from: { email: fromEmail, name: fromName },
            reply_to: { email: replyTo, name: fromName },
            subject: String(proposal.subject).slice(0, 240),
            content: [
              { type: 'text/plain', value: textBody },
              { type: 'text/html', value: htmlBody },
            ],
            headers: { 'List-Unsubscribe': '<' + optOutAddress + '>' },
            custom_args: { listingcraft_proposal_id: proposalId },
            tracking_settings: {
              click_tracking: { enable: false },
              open_tracking: { enable: false },
            },
          }),
        });

        const responseText = await response.text();
        if (response.status !== 202) {
          let providerMessage = 'SendGrid rejected the message (HTTP ' + response.status + ').';
          try {
            const providerData = JSON.parse(responseText) as { errors?: Array<{ message?: string }> };
            const detail = providerData.errors?.map(item => item.message).filter(Boolean).join('; ');
            if (detail) providerMessage += ' ' + detail.slice(0, 500);
          } catch { /* Do not expose unparsed provider responses. */ }
          await db.tx.update(table, [{
            id: proposalId,
            record: { status: 'Failed', lastSendError: providerMessage.slice(0, 700), sendFailedAt: new Date().toISOString() },
            if: { status: 'Sending' },
          }], { patch: true });
          return error(providerMessage, response.status === 401 || response.status === 403 ? 502 : 502);
        }

        const acceptedAt = new Date().toISOString();
        const providerMessageId = response.headers.get('x-message-id') || '';
        const [updated] = await db.tx.update(table, [{
          id: proposalId,
          record: {
            status: 'Accepted',
            acceptedAt,
            providerMessageId,
            senderEmail: fromEmail,
            lastSendError: '',
          },
          if: { status: 'Sending' },
        }], { patch: true });
        if (!updated) {
          return error('SendGrid accepted this email, but ListingCraft could not update the draft status. Do not resend; contact support and quote proposal ' + proposalId + '.', 500);
        }
        return json({
          sent: true,
          status: 'Accepted',
          acceptedAt,
          providerMessageId,
          recipientEmail: proposal.recipientEmail,
          note: 'SendGrid accepted the request. This does not confirm inbox delivery; bounces or later delivery events may still occur.',
        });
      } catch (err) {
        console.error('ListingCraft SendGrid send failed', err);
        await db.tx.update(table, [{
          id: proposalId,
          record: { status: 'Failed', lastSendError: 'Provider request failed before acceptance.', sendFailedAt: new Date().toISOString() },
          if: { status: 'Sending' },
        }], { patch: true });
        return error('The email provider could not be reached. No delivery was confirmed; check the draft status before retrying.', 502);
      }
    },
  ],

  'GET /api/opportunities': [
    requireAuth(),
    async ({ user }) => {
      const page = await db.list<Record<string, any>>(opportunityTable(user!.userId), { limit: 100 });
      return json({ opportunities: page.items.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))) });
    },
  ],

  'POST /api/opportunities': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as { kind?: string; title?: string; location?: string; industry?: string; sourceUrl?: string; details?: string };
      if (!['business', 'property'].includes(input.kind || '')) return error('Choose a business or property opportunity.', 400);
      if (!input.title?.trim() || !input.location?.trim()) return error('A title and location are required.', 400);
      const sourceUrl = (input.sourceUrl || '').trim();
      if (sourceUrl) {
        try {
          const parsed = new URL(sourceUrl);
          if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password) return error('Use a valid public HTTP or HTTPS source URL.', 400);
        } catch { return error('Use a valid public source URL.', 400); }
      }
      const opportunity = {
        kind: input.kind,
        title: input.title.trim().slice(0, 180),
        location: input.location.trim().slice(0, 160),
        industry: (input.industry || '').trim().slice(0, 120),
        sourceUrl: sourceUrl.slice(0, 500),
        details: (input.details || '').trim().slice(0, 1800),
        status: 'New',
        createdAt: new Date().toISOString(),
      };
      const [id] = await db.add(opportunityTable(user!.userId), [{ ...opportunity, userId: user!.userId }]);
      if (!id) return error('Could not save this opportunity.', 500);
      return json({ opportunity: { ...opportunity, id } }, 201);
    },
  ],

  'POST /api/billing/checkout': [
    requireAuth(),
    async ({ body, user }) => {
      const input = (body || {}) as { plan?: string; currency?: string; paymentMethod?: string };
      const plan = input.plan as Exclude<Plan, 'free'>;
      const currency = (input.currency || 'kes').toLowerCase();
      const paymentMethod = (input.paymentMethod || 'card').toLowerCase();
      if (!['starter', 'growth', 'agency'].includes(plan)) return error('Choose a valid subscription plan.', 400);
      if (currency !== 'kes') return error('This ListingCraft Paystack account is configured for KES only. Select KES to continue.', 400);
      if (!['card', 'mpesa'].includes(paymentMethod)) return error('Choose card or M-PESA.', 400);
      try {
        const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
        if (profile.subscriptionStatus === 'active' && profile.plan === plan) return error('This plan is already active.', 409);
        if (!user!.email) return error('Add an email address to your account before starting checkout.', 400);
        await db.tx.add('lc_paystack_email_map', [{ id: emailKey(user!.email), userId: user!.userId }]);

        const metadata = { userId: user!.userId, plan, paymentMethod };
        const payload: Record<string, unknown> = {
          email: user!.email,
          amount: String(PLAN_PRICES[plan][currency]),
          currency: currency.toUpperCase(),
          callback_url: appUrl() + '?billing=success',
          metadata,
        };
        if (paymentMethod === 'mpesa') {
          payload.channels = ['mobile_money'];
        } else {
          const planCode = await ensurePaystackPlan(plan, currency);
          payload.plan = planCode;
          payload.channels = ['card'];
        }
        const transaction = await paystackRequest('transaction/initialize', 'POST', payload);
        const checkoutUrl = transaction.data?.authorization_url as string | undefined;
        if (!checkoutUrl) return error('Paystack did not return a checkout link.', 502);
        return json({ url: checkoutUrl, reference: transaction.data.reference, paymentMethod });
      } catch (err) {
        console.error('Paystack checkout setup failed', err);
        return error('Paystack checkout could not be started. Confirm your Paystack secret key, account activation and enabled currency, then try again.', 503);
      }
    },
  ],

  'POST /api/billing/confirm': [
    requireAuth(),
    async ({ body, user }) => {
      const reference = (body as { reference?: string } | null)?.reference;
      if (!reference || !/^[A-Za-z0-9.=\-]{8,100}$/.test(reference)) return error('A valid Paystack payment reference is required.', 400);
      try {
        const verified = await paystackRequest('transaction/verify/' + encodeURIComponent(reference), 'GET');
        const payment = verified.data || {};
        if (payment.status !== 'success') return error('The payment has not been completed yet.', 409);
        if (String(payment.reference || '') !== reference) return error('The verified payment reference does not match this checkout.', 409);
        const metadata = payment.metadata || {};
        if (metadata.userId !== user!.userId) return error('This payment belongs to another account.', 403);
        const plan = metadata.plan as Exclude<Plan, 'free'>;
        const paymentMethod = metadata.paymentMethod as 'card' | 'mpesa';
        const currency = String(payment.currency || '').toUpperCase();
        if (!['starter', 'growth', 'agency'].includes(plan) || !['card', 'mpesa'].includes(paymentMethod)) {
          return error('The verified payment does not contain a valid ListingCraft plan.', 409);
        }
        if (currency !== 'KES' || Number(payment.amount) !== PLAN_PRICES[plan].kes) {
          return error('The verified payment amount or currency does not match the KES plan selected for this checkout.', 409);
        }
        const currentProfile = await getProfile(user!.userId, user!.email || '', user!.name || '');
        if (currentProfile.lastPaymentReference === reference) return json({ confirmed: true, plan: currentProfile.plan, paymentMethod: currentProfile.paymentMethod });
        await updateProfile(user!.userId, {
          plan,
          subscriptionStatus: 'active',
          paymentMethod,
          subscriptionExpiresAt: paymentMethod === 'mpesa' ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : '',
          paystackCustomerCode: payment.customer?.customer_code || '',
          lastPaymentReference: reference,
        });
        return json({ confirmed: true, plan, paymentMethod });
      } catch (err) {
        console.error('Paystack payment confirmation failed', err);
        return error('We could not verify the Paystack payment yet. If you completed payment, wait briefly and refresh Billing.', 502);
      }
    },
  ],

  'GET /api/billing/status': [
    requireAuth(),
    async ({ user }) => {
      const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
      const usage = await getUsage(user!.userId);
      const count = usage.month === MONTH() ? usage.count : 0;
      return json({
        plan: profile.plan,
        planName: PLAN_LABELS[profile.plan],
        subscriptionStatus: profile.subscriptionStatus,
        hasCustomer: Boolean(profile.paystackCustomerCode || profile.paystackSubscriptionCode),
        paymentMethod: profile.paymentMethod,
        subscriptionExpiresAt: profile.subscriptionExpiresAt,
        usage: { count, limit: PLAN_LIMITS[profile.plan], month: MONTH() },
      });
    },
  ],

  'POST /api/billing/portal': [
    requireAuth(),
    async ({ user }) => {
      const profile = await getProfile(user!.userId, user!.email || '', user!.name || '');
      if (!profile.paystackSubscriptionCode) return error('A recurring card subscription is not linked to this account yet. M-PESA plans renew manually.', 409);
      try {
        const result = await paystackRequest('subscription/' + encodeURIComponent(profile.paystackSubscriptionCode) + '/manage/link', 'GET');
        const url = result.data?.link as string | undefined;
        if (!url) return error('Paystack did not return a subscription management link.', 502);
        return json({ url });
      } catch (err) {
        console.error('Paystack subscription management link failed', err);
        return error('Paystack subscription management is not available yet. Please try again later.', 503);
      }
    },
  ],

  'POST /api/billing/webhook': [
    async ({ event }) => {
      try {
        const rawBody = typeof event.body === 'string'
          ? (event.isBase64Encoded ? atob(event.body) : event.body)
          : '';
        const headers = (event.headers || {}) as Record<string, string>;
        if (!rawBody || !(await verifyPaystackSignature(rawBody, headers))) {
          return error('Invalid Paystack webhook signature.', 401);
        }
        const paystackEvent = JSON.parse(rawBody) as { event: string; data?: Record<string, any> };
        const object = paystackEvent.data || {};
        const metadata = object.metadata || {};
        const customerEmail = object.customer?.email || object.customer_email || '';
        const eventUserId = String(metadata.userId || await userIdForEmail(customerEmail) || '');
        const eventPlan = (['starter', 'growth', 'agency'].includes(metadata.plan) ? metadata.plan : await planFromName(object.plan?.name || '')) as Plan;
        const customerCode = object.customer?.customer_code || object.customer_code || '';

        if (paystackEvent.event === 'charge.success') {
          const paymentReference = String(object.reference || '');
          if (!paymentReference) return error('Paystack charge event did not include a payment reference.', 409);
          const verified = await paystackRequest('transaction/verify/' + encodeURIComponent(paymentReference), 'GET');
          const payment = verified.data || {};
          if (payment.status !== 'success' || String(payment.reference || '') !== paymentReference) {
            return error('Paystack transaction verification did not confirm this payment reference.', 409);
          }
          const verifiedMetadata = payment.metadata || {};
          const userId = String(verifiedMetadata.userId || '');
          const plan = String(verifiedMetadata.plan || '') as Exclude<Plan, 'free'>;
          const paymentMethod = String(verifiedMetadata.paymentMethod || '');
          if (!userId) return error('Verified Paystack payment is missing its ListingCraft account reference.', 403);
          if (!['starter', 'growth', 'agency'].includes(plan) || !['card', 'mpesa'].includes(paymentMethod)) {
            return error('Verified Paystack payment does not contain a valid ListingCraft plan.', 409);
          }
          if (String(payment.currency || '').toUpperCase() !== 'KES' || Number(payment.amount) !== PLAN_PRICES[plan].kes) {
            return error('Verified Paystack payment amount or currency does not match the KES plan.', 409);
          }
          const currentProfile = await getProfile(userId);
          const verifiedEmail = String(payment.customer?.email || '');
          if (verifiedEmail && currentProfile.email && verifiedEmail.toLowerCase() !== currentProfile.email.toLowerCase()) {
            return error('Verified Paystack customer does not match this ListingCraft account.', 403);
          }
          if (currentProfile.lastPaymentReference !== paymentReference) {
            await updateProfile(userId, {
              plan,
              subscriptionStatus: 'active',
              paymentMethod: paymentMethod as 'card' | 'mpesa',
              subscriptionExpiresAt: paymentMethod === 'mpesa' ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : '',
              paystackCustomerCode: payment.customer?.customer_code || customerCode,
              lastPaymentReference: paymentReference,
            });
          }
        }

        if (paystackEvent.event === 'subscription.create' && eventUserId && eventPlan !== 'free') {
          await getProfile(eventUserId);
          await updateProfile(eventUserId, {
            paystackCustomerCode: customerCode,
            paystackSubscriptionCode: String(object.subscription_code || ''),
          });
        }

        if (paystackEvent.event === 'subscription.not_renew' && eventUserId) {
          const expiry = object.next_payment_date || object.expiry_date || '';
          await getProfile(eventUserId);
          await updateProfile(eventUserId, {
            subscriptionStatus: 'non_renewing',
            subscriptionExpiresAt: expiry,
          });
        }

        if (paystackEvent.event === 'subscription.disable' && eventUserId) {
          await getProfile(eventUserId);
          await updateProfile(eventUserId, {
            plan: 'free',
            subscriptionStatus: 'canceled',
            paystackSubscriptionCode: '',
            subscriptionExpiresAt: '',
          });
        }

        if (paystackEvent.event === 'invoice.payment_failed' && eventUserId) {
          await getProfile(eventUserId);
          await updateProfile(eventUserId, { subscriptionStatus: 'past_due' });
        }

        return json({ received: true });
      } catch (err) {
        console.error('Paystack webhook processing failed', err);
        return error('Webhook processing failed.', 500);
      }
    },
  ],
});